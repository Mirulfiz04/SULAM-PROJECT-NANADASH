<?php
// Just include db.php, no more logic here
require 'db.php';
?>

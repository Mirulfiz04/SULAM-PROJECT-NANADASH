<?php

// --- CORS + JSON headers (needed for Flutter Web) ---
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Content-Type: application/json; charset=UTF-8");

header('Content-Type: application/json');

// ✅ use the SAME DB file as login.php
require 'db.php';   // this provides $conn (mysqli) connected to DB "flutter"

// --------------- READ INPUT -----------------
$title      = $_POST['title']      ?? '';
$content    = $_POST['content']    ?? '';
$created_by = $_POST['created_by'] ?? 'admin';  // optional, default admin

// Simple validation
if (trim($title) === '' || trim($content) === '') {
    echo json_encode([
        "success" => false,
        "message" => "Title and content are required."
    ]);
    exit;
}

// --------------- HANDLE IMAGE (OPTIONAL) -----------------
$image_url = null;

if (!empty($_FILES['image']['name'])) {
    $uploadDir = 'uploads/';

    // Create folder if not exists
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    $fileName   = time() . '_' . basename($_FILES['image']['name']);
    $targetPath = $uploadDir . $fileName;

    if (move_uploaded_file($_FILES['image']['tmp_name'], $targetPath)) {
        // ✅ full URL used by Flutter (Image.network)
        $image_url = 'http://localhost/flutter_api/' . $targetPath;
    }
}


$sql = "INSERT INTO news (title, content, image_url, created_by)
        VALUES (?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ssss", $title, $content, $image_url, $created_by);

if ($stmt->execute()) {
    echo json_encode([
        "success" => true,
        "message" => "News created successfully"
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Failed to create news: " . $stmt->error
    ]);
}

$stmt->close();
$conn->close();

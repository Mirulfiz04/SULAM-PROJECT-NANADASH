<?php
header('Content-Type: application/json');
require 'config.php';   // or db_config.php / db.php (your connection file)

// Only allow POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
    exit;
}

$customer_id      = intval($_POST['customer_id'] ?? 0);
$product_id       = intval($_POST['product_id'] ?? 0);
$quantity         = intval($_POST['quantity'] ?? 0);
$transport_cost   = floatval($_POST['transport_cost'] ?? 0);
$delivery_address = trim($_POST['delivery_address'] ?? '');
$delivery_notes   = trim($_POST['delivery_notes'] ?? '');

// Basic validation
if ($customer_id <= 0 || $product_id <= 0 || $quantity <= 0 || $delivery_address === '') {
    echo json_encode([
        'success' => false,
        'message' => 'Missing or invalid data'
    ]);
    exit;
}

// 1) Get product price
$sql = "SELECT base_price FROM products WHERE product_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $product_id);
$stmt->execute();
$stmt->bind_result($base_price);

if (!$stmt->fetch()) {
    echo json_encode([
        'success' => false,
        'message' => 'Product not found'
    ]);
    $stmt->close();
    $conn->close();
    exit;
}
$stmt->close();

$subtotal    = $base_price * $quantity;
$tax_amount  = $subtotal * 0.06;  // 6% tax
$total_amount = $subtotal + $tax_amount + $transport_cost;

// 2) Insert into orders (NO accepted_by / accepted_at here!)
$sql = "INSERT INTO orders
        (customer_id, status, subtotal, tax_amount, transport_cost, total_amount,
         delivery_address, delivery_notes)
        VALUES (?, 'pending', ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param(
    "iddddss",
    $customer_id,
    $subtotal,
    $tax_amount,
    $transport_cost,
    $total_amount,
    $delivery_address,
    $delivery_notes
);
if (!$stmt->execute()) {
    echo json_encode([
        'success' => false,
        'message' => 'Failed to create order: ' . $stmt->error
    ]);
    $stmt->close();
    $conn->close();
    exit;
}

$order_id = $stmt->insert_id;
$stmt->close();

// 3) Insert into order_items
$sql = "INSERT INTO order_items (order_id, product_id, quantity, unit_price, line_total)
        VALUES (?, ?, ?, ?, ?)";
$line_total = $base_price * $quantity;

$stmt = $conn->prepare($sql);
$stmt->bind_param("iiidd", $order_id, $product_id, $quantity, $base_price, $line_total);

if (!$stmt->execute()) {
    echo json_encode([
        'success' => false,
        'message' => 'Order created but failed to insert items: ' . $stmt->error
    ]);
    $stmt->close();
    $conn->close();
    exit;
}

$stmt->close();
$conn->close();

echo json_encode([
    'success' => true,
    'message' => 'Order created successfully',
    'order_id' => $order_id,
    'total_amount' => $total_amount
]);

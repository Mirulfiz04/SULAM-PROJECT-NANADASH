<?php
// CORS + JSON headers (for Flutter Web and mobile)
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Content-Type: application/json; charset=UTF-8");

// Preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require 'config.php'; // makes $conn

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
    exit();
}

// ---- Read basic fields ----
$name        = trim($_POST['name'] ?? '');
$description = trim($_POST['description'] ?? '');
$condition   = trim($_POST['order_condition'] ?? '');
$unitPrice   = isset($_POST['unit_price']) ? floatval($_POST['unit_price']) : 0;

// Basic validation
if ($name === '' || $unitPrice <= 0) {
    echo json_encode([
        'success' => false,
        'message' => 'Name and valid unit price are required'
    ]);
    exit();
}

// ---- Optional image upload ----
$imageUrl = null;

if (!empty($_FILES['image']['name'])) {
    $uploadDir = __DIR__ . '/uploads/products/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
    $fileName = time() . '_product.' . $ext;
    $targetPath = $uploadDir . $fileName;

    if (move_uploaded_file($_FILES['image']['tmp_name'], $targetPath)) {
        // Store relative path or full URL – here relative:
        $imageUrl = 'uploads/products/' . $fileName;
    }
}

// ---- INSERT into the real columns of your table ----
// IMPORTANT: these column names must exist in your `products` table
//   id (PK, auto_increment)
//   name
//   description
//   order_condition
//   unit_price
//   is_active
//   image_url   (NULL allowed)
$sql = "
    INSERT INTO products
      (name, description, order_condition, unit_price, is_active, image_url)
    VALUES
      (?,    ?,           ?,               ?,         1,        ?)
";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    echo json_encode([
        'success' => false,
        'message' => 'Prepare failed: ' . $conn->error
    ]);
    exit();
}

$stmt->bind_param("sssds", $name, $description, $condition, $unitPrice, $imageUrl);

if ($stmt->execute()) {
    echo json_encode([
        'success' => true,
        'message' => 'Product created successfully'
    ]);
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Failed to create product: ' . $stmt->error
    ]);
}

$stmt->close();
$conn->close();

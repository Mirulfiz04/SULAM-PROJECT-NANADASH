<?php
$host = "localhost";   // default XAMPP host
$user = "root";        // default XAMPP user
$pass = "";            // default XAMPP password is empty
$db   = "flutter_auth"; // <-- your database name

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    // Always JSON style error
    die(json_encode([
        "success" => false,
        "message" => "Database connection failed: " . $conn->connect_error
    ]));
}
?>

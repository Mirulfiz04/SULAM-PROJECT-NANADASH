<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, X-Requested-With");
header("Access-Control-Allow-Methods: POST, OPTIONS");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

header('Content-Type: application/json');
require 'db.php';

$name  = $_POST['name']  ?? '';
$phone = $_POST['phone'] ?? '';

if ($name === '' || $phone === '') {
    echo json_encode([
        "success" => false,
        "message" => "Name and phone are required."
    ]);
    exit;
}

$stmt = $conn->prepare(
    "SELECT email FROM users WHERE name = ? AND phonenumber = ? LIMIT 1"
);
$stmt->bind_param("ss", $name, $phone);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    echo json_encode([
        "success" => true,
        "message" => "Email found.",
        "email"   => $row['email']
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "No account found with that name and phone."
    ]);
}

$stmt->close();
$conn->close();
?>

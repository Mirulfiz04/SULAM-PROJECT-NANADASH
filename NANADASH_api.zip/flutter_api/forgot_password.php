<?php
header('Content-Type: application/json');
require 'db.php';

$email       = $_POST['email']        ?? '';
$newPassword = $_POST['new_password'] ?? '';

if ($email === '' || $newPassword === '') {
    echo json_encode([
        "success" => false,
        "message" => "Email and new password are required."
    ]);
    exit;
}

// check user exists
$stmt = $conn->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    $userId = $row['id'];
    $hashed = password_hash($newPassword, PASSWORD_DEFAULT);

    $stmt->close();

    // update password
    $update = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
    $update->bind_param("si", $hashed, $userId);

    if ($update->execute()) {
        echo json_encode([
            "success" => true,
            "message" => "Password updated successfully."
        ]);
    } else {
        echo json_encode([
            "success" => false,
            "message" => "Failed to update password."
        ]);
    }
    $update->close();
} else {
    echo json_encode([
        "success" => false,
        "message" => "No user found with that email."
    ]);
}

$conn->close();
?>

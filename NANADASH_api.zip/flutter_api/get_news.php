<?php
// ---- CORS for Flutter Web ----
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

header('Content-Type: application/json');

// ✅ use the SAME DB connection as login.php / create_news.php
require 'db.php';   // gives you $conn (mysqli)

// Get latest news
$sql = "SELECT id, title, content, image_url, created_by, created_at
        FROM news
        ORDER BY created_at DESC";

$result = $conn->query($sql);

$rows = [];

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $rows[] = $row;
    }
}

// Return a plain JSON array (what your Flutter code expects)
echo json_encode($rows);

$conn->close();

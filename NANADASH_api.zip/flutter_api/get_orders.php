<?php
// --- CORS + JSON headers (needed for Flutter Web) ---
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Content-Type: application/json; charset=UTF-8");

// Preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require 'config.php';   // includes $conn

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
    exit();
}

// Optional filters
$customerId = isset($_GET['customer_id']) ? intval($_GET['customer_id']) : 0;
$status     = isset($_GET['status']) ? trim($_GET['status']) : '';

// ---------------------------------------------------------------------
// MAIN QUERY
//   - orders  (alias o)
//   - users   (alias u)
//   - order_items + products via subqueries to get quantity + name
// ---------------------------------------------------------------------

$sql = "
    SELECT
        o.order_id,
        o.customer_id,
        o.order_date,       
        o.status,
        o.subtotal,
        o.tax_amount,
        o.transport_cost,
        o.total_amount,
        o.delivery_address,
        o.delivery_notes,
        o.accepted_by,
        o.accepted_at,
        u.name AS customer_name,

        -- TOTAL QUANTITY (sum of all items in this order)
        (
            SELECT COALESCE(SUM(oi.quantity), 0)
            FROM order_items oi
            WHERE oi.order_id = o.order_id
        ) AS quantity,

        -- PRODUCT NAME(S) (comma separated if multiple)
        (
            SELECT GROUP_CONCAT(p.name SEPARATOR ', ')
            FROM order_items oi
            JOIN products p ON p.product_id = oi.product_id 
            WHERE oi.order_id = o.order_id
            ) AS product_name

    FROM orders o
    JOIN users u ON u.id = o.customer_id
";

// WHERE conditions (customer_id / status)
$conditions = [];
$params     = [];
$types      = '';

if ($customerId > 0) {
    $conditions[] = "o.customer_id = ?";
    $params[]     = $customerId;
    $types       .= "i";
}

if ($status !== '') {
    $conditions[] = "o.status = ?";
    $params[]     = $status;
    $types       .= "s";
}

if (!empty($conditions)) {
    $sql .= " WHERE " . implode(" AND ", $conditions);
}

$sql .= " ORDER BY o.order_date DESC, o.order_id DESC";

// ---------------------------------------------------------------------
// EXECUTE (prepared if we have parameters)
// ---------------------------------------------------------------------
if (!empty($params)) {
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        echo json_encode([
            'success' => false,
            'message' => 'Prepare failed: ' . $conn->error
        ]);
        exit();
    }

    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query($sql);
}

if (!$result) {
    echo json_encode([
        'success' => false,
        'message' => 'Query error: ' . $conn->error
    ]);
    exit();
}

// ---------------------------------------------------------------------
// BUILD JSON
// ---------------------------------------------------------------------
$orders = [];
while ($row = $result->fetch_assoc()) {
    $orders[] = [
        'order_id'       => (int)$row['order_id'],
        'customer_id'    => (int)$row['customer_id'],

        // 👇 NEW FIELDS
        'customer_name'  => $row['customer_name'] ?? '',
        'customer_email' => $row['customer_email'] ?? '',
        'customer_phone' => $row['customer_phone'] ?? '',

        'order_date'     => $row['order_date'],                 // requested time
        'status'         => $row['status'] ?: 'pending',
        'product_name'   => $row['product_name'] ?: 'Unknown product',
        'quantity'       => isset($row['quantity']) ? (int)$row['quantity'] : 0,
        'subtotal'       => (float)$row['subtotal'],
        'tax_amount'     => (float)$row['tax_amount'],
        'transport_cost' => (float)$row['transport_cost'],
        'total_amount'   => (float)$row['total_amount'],
        'delivery_address' => $row['delivery_address'] ?? '',
        'delivery_notes'   => $row['delivery_notes'] ?? '',
        'accepted_by'      => $row['accepted_by'],
        'accepted_at'      => $row['accepted_at'],              // accepted time
    ];
}

echo json_encode([
    'success' => true,
    'orders'  => $orders,
]);

if (isset($stmt)) {
    $stmt->close();
}
$conn->close();

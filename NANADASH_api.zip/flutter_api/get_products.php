<?php
// CORS + JSON headers (needed for Flutter Web)
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require 'config.php'; // this should create $conn (mysqli)

// Only GET
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method',
    ]);
    exit();
}

$sql = "
    SELECT 
        id,
        product_name,
        description,
        order_condition,
        unit_price,
        is_active
    FROM products
    ORDER BY id DESC
";

$result = $conn->query($sql);

if (!$result) {
    echo json_encode([
        'success' => false,
        'message' => 'Query error: ' . $conn->error,
    ]);
    exit();
}

$products = [];
while ($row = $result->fetch_assoc()) {
    $products[] = [
        'id'              => (int)$row['id'],
        'product_name'    => $row['product_name'],
        'description'     => $row['description'],
        'order_condition' => $row['order_condition'],
        'unit_price'      => (float)$row['unit_price'],
        'is_active'       => (int)$row['is_active'],
    ];
}

// You can return just $products, or wrap it.
echo json_encode($products);
// or: echo json_encode(['success' => true, 'products' => $products]);

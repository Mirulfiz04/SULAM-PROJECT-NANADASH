<?php
// ---- CORS ----
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, X-Requested-With");
header("Access-Control-Allow-Methods: POST, OPTIONS");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

header('Content-Type: application/json');
require 'db.php';

$name     = $_POST['name']     ?? '';
$email    = $_POST['email']    ?? '';
$password = $_POST['password'] ?? '';
$phone    = $_POST['phone']    ?? '';
$role     = $_POST['role']     ?? 'customer';  // 👈 NEW

if ($name === '' || $email === '' || $password === '' || $phone === '') {
    echo json_encode([
        "success" => false,
        "message" => "All fields are required."
    ]);
    exit;
}

// check duplicate email / phone
$stmt = $conn->prepare("SELECT id FROM users WHERE email = ? OR phonenumber = ?");
$stmt->bind_param("ss", $email, $phone);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    echo json_encode([
        "success" => false,
        "message" => "Email or phone already in use."
    ]);
    $stmt->close();
    $conn->close();
    exit;
}
$stmt->close();

$hashed = password_hash($password, PASSWORD_DEFAULT);

// 👇 insert with role
$stmt = $conn->prepare(
    "INSERT INTO users (name, email, password, phonenumber, role)
     VALUES (?, ?, ?, ?, ?)"
);
$stmt->bind_param("sssss", $name, $email, $hashed, $phone, $role);

if ($stmt->execute()) {
    echo json_encode([
        "success" => true,
        "message" => "Registration successful."
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Failed to register user: " . $stmt->error
    ]);
}

$stmt->close();
$conn->close();

<?php
header('Content-Type: application/json');
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
    exit;
}

$order_id = intval($_POST['order_id'] ?? 0);
$status   = $_POST['status'] ?? '';
$admin_id = intval($_POST['admin_id'] ?? 0);

if ($order_id <= 0 || $status == '') {
    echo json_encode(['success' => false, 'message' => 'Missing data']);
    exit;
}

if ($status === 'accepted' && $admin_id > 0) {
    $sql = "UPDATE orders 
            SET status = ?, accepted_by = ?, accepted_at = NOW() 
            WHERE order_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sii", $status, $admin_id, $order_id);

} else {
    $sql = "UPDATE orders SET status = ? WHERE order_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $status, $order_id);
}

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Order updated']);
} else {
    echo json_encode(['success' => false, 'message' => $conn->error]);
}

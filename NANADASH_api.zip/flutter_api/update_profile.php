<?php
// update_profile.php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, X-Requested-With");
header("Access-Control-Allow-Methods: POST, OPTIONS");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

header('Content-Type: application/json');
require 'db.php';

$id    = $_POST['id']    ?? '';
$name  = $_POST['name']  ?? '';
$phone = $_POST['phone'] ?? '';

if ($id === '' || $name === '' || $phone === '') {
    echo json_encode([
        "success" => false,
        "message" => "ID, name and phone are required."
    ]);
    exit;
}

// optional: make sure phone is unique for other users
$stmt = $conn->prepare("SELECT id FROM users WHERE phonenumber = ? AND id <> ?");
$stmt->bind_param("si", $phone, $id);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    echo json_encode([
        "success" => false,
        "message" => "Phone number already used by another account."
    ]);
    $stmt->close();
    $conn->close();
    exit;
}
$stmt->close();

// update
$stmt = $conn->prepare(
    "UPDATE users SET name = ?, phonenumber = ? WHERE id = ?"
);
$stmt->bind_param("ssi", $name, $phone, $id);

if ($stmt->execute()) {
    echo json_encode([
        "success" => true,
        "message" => "Profile updated successfully."
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Failed to update profile: " . $stmt->error
    ]);
}

$stmt->close();
$conn->close();

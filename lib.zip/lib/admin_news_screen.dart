import 'dart:io' show File; // still fine; we guard usage with kIsWeb
import 'dart:typed_data';

import 'package:flutter/foundation.dart'; // kIsWeb
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import 'auth_service.dart';

class AdminNewsScreen extends StatefulWidget {
  const AdminNewsScreen({super.key});

  @override
  State<AdminNewsScreen> createState() => _AdminNewsScreenState();
}

class _AdminNewsScreenState extends State<AdminNewsScreen> {
  static const Color _orange = Color(0xFFF97316);
  static const Color _purple = Color(0xFF9333EA);

  final titleC = TextEditingController();
  final contentC = TextEditingController();

  File? _imageFile; // for mobile/desktop
  Uint8List? _webImageBytes; // for web

  final picker = ImagePicker();
  bool _submitting = false;

  Future<void> pickImage() async {
    final img = await picker.pickImage(source: ImageSource.gallery);
    if (img == null) return;

    if (kIsWeb) {
      final bytes = await img.readAsBytes();
      setState(() {
        _webImageBytes = bytes;
        _imageFile = null;
      });
    } else {
      setState(() {
        _imageFile = File(img.path);
        _webImageBytes = null;
      });
    }
  }

  Future<void> submitNews() async {
    final title = titleC.text.trim();
    final content = contentC.text.trim();

    if (title.isEmpty || content.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Title and content are required.')),
      );
      return;
    }

    setState(() => _submitting = true);

    final res = await AuthService.createNews(
      title: title,
      content: content,
      imageFile: kIsWeb ? null : _imageFile,
      webImageBytes: kIsWeb ? _webImageBytes : null,
    );

    setState(() => _submitting = false);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(res['message']?.toString() ?? 'Done')),
    );

    if (res['success'] == true) {
      setState(() {
        titleC.clear();
        contentC.clear();
        _imageFile = null;
        _webImageBytes = null;
      });
    }
  }

  Widget _buildPreview() {
    final borderRadius = BorderRadius.circular(18);

    Widget child;
    if (kIsWeb) {
      if (_webImageBytes == null) {
        child = const Center(
          child: Text(
            'No image selected\n(Recommended: 16:9 banner)',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.black54, fontSize: 12),
          ),
        );
      } else {
        child = ClipRRect(
          borderRadius: borderRadius,
          child: Image.memory(
            _webImageBytes!,
            fit: BoxFit.cover,
          ),
        );
      }
    } else {
      if (_imageFile == null) {
        child = const Center(
          child: Text(
            'No image selected\n(Recommended: 16:9 banner)',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.black54, fontSize: 12),
          ),
        );
      } else {
        child = ClipRRect(
          borderRadius: borderRadius,
          child: Image.file(
            _imageFile!,
            fit: BoxFit.cover,
          ),
        );
      }
    }

    return Container(
      height: 170,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: borderRadius,
        border: Border.all(color: Colors.orange.withOpacity(0.3)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.10),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: child,
    );
  }

  @override
  void dispose() {
    titleC.dispose();
    contentC.dispose();
    super.dispose();
  }

  InputDecoration _fieldDecoration(String label) {
    return InputDecoration(
      labelText: label,
      labelStyle: const TextStyle(color: Colors.black87),
      filled: true,
      fillColor: Colors.white,
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide(color: Colors.orange.withOpacity(0.3)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: const BorderSide(color: _orange, width: 1.8),
      ),
      contentPadding:
      const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
    );
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    // keep form nice and compact on large screens
    final formWidth = screenWidth > 900 ? 700.0 : screenWidth * 0.9;

    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        foregroundColor: _orange,
        title: const Text(
          'Create News',
          style: TextStyle(
            color: Colors.black87,
            fontWeight: FontWeight.w600,
          ),
        ),
        bottom: const PreferredSize(
          preferredSize: Size.fromHeight(2),
          child: SizedBox(
            height: 2,
            child: DecoratedBox(
              decoration: BoxDecoration(color: _purple),
            ),
          ),
        ),
      ),
      body: Stack(
        children: [
          // 🍍 pineapple background
          Positioned.fill(
            child: Image.asset(
              'assets/image/admin_announcement.png',
              fit: BoxFit.cover,
            ),
          ),

          // 📄 form card
          Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: SizedBox(
                width: formWidth,
                child: Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.94),
                    borderRadius: BorderRadius.circular(24),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.18),
                        blurRadius: 14,
                        offset: const Offset(0, 6),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Publish New Announcement',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                          color: Colors.black87,
                        ),
                      ),
                      const SizedBox(height: 4),
                      const Text(
                        'Share promotions, farm updates, or any important news with your customers.',
                        style: TextStyle(
                          fontSize: 13,
                          color: Colors.black54,
                        ),
                      ),
                      const SizedBox(height: 20),

                      // Title
                      TextField(
                        controller: titleC,
                        decoration: _fieldDecoration('Title'),
                      ),
                      const SizedBox(height: 14),

                      // Content
                      TextField(
                        controller: contentC,
                        maxLines: 4,
                        decoration: _fieldDecoration('Content / Description'),
                      ),
                      const SizedBox(height: 18),

                      // Image preview
                      const Text(
                        'News banner (optional)',
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          color: Colors.black87,
                        ),
                      ),
                      const SizedBox(height: 8),
                      _buildPreview(),
                      const SizedBox(height: 10),

                      // Pick image button
                      Align(
                        alignment: Alignment.centerRight,
                        child: TextButton.icon(
                          onPressed: _submitting ? null : pickImage,
                          icon: const Icon(Icons.photo_library_outlined),
                          label: const Text('Pick Image (optional)'),
                          style: TextButton.styleFrom(
                            foregroundColor: _orange,
                            padding: const EdgeInsets.symmetric(
                                horizontal: 12, vertical: 8),
                          ),
                        ),
                      ),

                      const SizedBox(height: 10),
                      const Divider(height: 24),

                      // Publish button
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed: _submitting ? null : submitNews,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: _orange,
                            foregroundColor: Colors.black,
                            padding: const EdgeInsets.symmetric(
                                vertical: 14, horizontal: 16),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(24),
                            ),
                            textStyle: const TextStyle(
                              fontWeight: FontWeight.w700,
                              fontSize: 15,
                            ),
                          ),
                          child: _submitting
                              ? const SizedBox(
                            height: 20,
                            width: 20,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              valueColor: AlwaysStoppedAnimation<Color>(
                                Colors.black,
                              ),
                            ),
                          )
                              : const Text('Publish News'),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

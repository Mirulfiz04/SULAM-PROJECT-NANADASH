import 'package:flutter/material.dart';
import 'auth_service.dart';

class AdminOrdersScreen extends StatefulWidget {
  const AdminOrdersScreen({super.key});

  @override
  State<AdminOrdersScreen> createState() => _AdminOrdersScreenState();
}

class _AdminOrdersScreenState extends State<AdminOrdersScreen> {
  static const Color _orange = Color(0xFFF97316);
  static const Color _purple = Color(0xFF9333EA);

  late Future<List<Map<String, dynamic>>> _futureOrders;

  @override
  void initState() {
    super.initState();
    _futureOrders = _loadOrders();
  }

  /// getAdminOrders() should return:
  /// { "success": true, "orders": [ {...}, {...} ] }
  Future<List<Map<String, dynamic>>> _loadOrders() async {
    final res = await AuthService.getAdminOrders();

    if (res['success'] == true && res['orders'] is List) {
      return List<Map<String, dynamic>>.from(res['orders']);
    }
    return [];
  }

  void _reload() {
    setState(() {
      _futureOrders = _loadOrders();
    });
  }

  /// Call your PHP to update order status
  Future<void> _updateStatus(
      Map<String, dynamic> order, String newStatus) async {
    final rawId = order['order_id'] ?? order['id'] ?? order['orderId'] ?? '';

    if (rawId == null || rawId.toString().isEmpty) return;

    final orderIdInt =
    rawId is int ? rawId : int.tryParse(rawId.toString()) ?? 0;

    final bool success = await AuthService.updateOrderStatus(
      orderId: orderIdInt,
      status: newStatus,
    );

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(success ? 'Order updated' : 'Failed to update order'),
      ),
    );

    if (success) {
      _reload();
    }
  }

  Color _statusColor(String status) {
    switch (status.toLowerCase()) {
      case 'accepted':
        return Colors.green;
      case 'rejected':
        return Colors.redAccent;
      default:
        return Colors.orange;
    }
  }

  String _fmtDate(String? s) {
    if (s == null || s.isEmpty || s == 'null') return '-';
    return s;
  }

  Widget _buildOrderCard(Map<String, dynamic> o) {
    // 🔁 Same field mapping as OrdersScreen (customer)
    final orderId = o['order_id']?.toString() ?? o['id']?.toString() ?? '-';
    final status = o['status']?.toString() ?? 'pending';
    final statusColor = _statusColor(status);

    final customerName  = o['customer_name']?.toString() ?? 'Unknown customer';
    final customerPhone = o['customer_phone']?.toString() ?? '';
    final customerEmail = o['customer_email']?.toString() ?? '';

    final product = o['product_name']?.toString() ?? 'Unknown product';
    final quantity = o['quantity']?.toString() ?? '-';

    final address = o['delivery_address']?.toString() ??
        o['delivery_addr']?.toString() ??
        '-';

    final orderDate = o['order_date']?.toString() ?? '-';
    final accepted = _fmtDate(o['accepted_at']?.toString());

    final totalRaw = o['total_amount'] ?? o['total'] ?? 0;
    final total = totalRaw.toString();

    final isPending = status.toLowerCase() == 'pending';

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.15),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // HEADER: Order id + status chip
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Order #$orderId',
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: Colors.black,
                ),
              ),
              Container(
                padding:
                const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: statusColor.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  status[0].toUpperCase() + status.substring(1),
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    color: statusColor,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),

          // Product + quantity
          Text(
            product,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color: Colors.black87,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'Customer: $customerName',
            style: const TextStyle(fontSize: 13, color: Colors.black87),
          ),
          if (customerPhone.isNotEmpty)
            Text(
              'Phone: $customerPhone',
              style: const TextStyle(fontSize: 12, color: Colors.black54),
            ),
// (optional)
          if (customerEmail.isNotEmpty)
            Text(
              'Email: $customerEmail',
              style: const TextStyle(fontSize: 12, color: Colors.black54),
            ),
          const SizedBox(height: 4),
          Text(
            'Quantity: $quantity',
            style: const TextStyle(fontSize: 13, color: Colors.black87),
          ),

          const SizedBox(height: 8),

          // Requested / accepted / address (same style as customer)
          Row(
            children: [
              const Icon(Icons.schedule, size: 14, color: Colors.black54),
              const SizedBox(width: 4),
              Text(
                'Requested: $orderDate',
                style:
                const TextStyle(fontSize: 12, color: Colors.black87),
              ),
            ],
          ),
          const SizedBox(height: 2),
          Row(
            children: [
              const Icon(Icons.check_circle_outline,
                  size: 14, color: Colors.black54),
              const SizedBox(width: 4),
              Text(
                'Accepted: $accepted',
                style:
                const TextStyle(fontSize: 12, color: Colors.black87),
              ),
            ],
          ),
          const SizedBox(height: 2),
          Row(
            children: [
              const Icon(Icons.location_on_outlined,
                  size: 14, color: Colors.black54),
              const SizedBox(width: 4),
              Expanded(
                child: Text(
                  address,
                  style:
                  const TextStyle(fontSize: 12, color: Colors.black87),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),

          const SizedBox(height: 10),

          // Total + actions
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // Left side: actions (or info text)
              if (isPending)
                Row(
                  children: [
                    TextButton(
                      onPressed: () => _updateStatus(o, 'rejected'),
                      child: const Text(
                        'Reject',
                        style: TextStyle(color: Colors.redAccent),
                      ),
                    ),
                    const SizedBox(width: 8),
                    ElevatedButton(
                      onPressed: () => _updateStatus(o, 'accepted'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _orange,
                        foregroundColor: Colors.black,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 8),
                      ),
                      child: const Text('Accept'),
                    ),
                  ],
                )
              else
                const Text(
                  'No action available',
                  style: TextStyle(
                    fontSize: 11,
                    color: Colors.black45,
                  ),
                ),

              // Right side: total
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text(
                    'Total ',
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 13,
                      color: Colors.black,      // ← ADDED
                    ),
                  ),
                  Text(
                    'RM $total',
                    style: const TextStyle(
                      fontWeight: FontWeight.w700,
                      fontSize: 14,
                      color: Colors.black,      // ← ADDED
                    ),
                  ),
                ],
              )
            ],
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,

      // Pineapple-style AppBar (same as other pineapple screens)
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        foregroundColor: _orange,
        title: const Text(
          'Customer Orders',
          style: TextStyle(
            color: Colors.black87,
            fontWeight: FontWeight.w600,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _reload,
          ),
        ],
        bottom: const PreferredSize(
          preferredSize: Size.fromHeight(2),
          child: SizedBox(
            height: 2,
            child: DecoratedBox(
              decoration: BoxDecoration(color: _purple),
            ),
          ),
        ),
      ),

      body: Stack(
        children: [
          // 🍍 background
          Positioned.fill(
            child: Image.asset(
              'assets/image/admin_manageproduct.png',
              fit: BoxFit.cover,
            ),
          ),

          FutureBuilder<List<Map<String, dynamic>>>(
            future: _futureOrders,
            builder: (context, snap) {
              if (snap.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }

              if (!snap.hasData || snap.data!.isEmpty) {
                return const Center(
                  child: Text(
                    'No orders yet',
                    style: TextStyle(color: Colors.white, fontSize: 16),
                  ),
                );
              }

              final orders = snap.data!;

              return LayoutBuilder(
                builder: (context, constraints) {
                  final screenWidth = constraints.maxWidth;

                  // Ideal card width ≈ 360, clamp between 1 and 3 columns
                  int crossAxisCount =
                  (screenWidth ~/ 360).clamp(1, 3);
                  final cardWidth = screenWidth / crossAxisCount;
                  final cardHeight = cardWidth * 0.38;

                  return GridView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: orders.length,
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: crossAxisCount,
                      crossAxisSpacing: 16,
                      mainAxisSpacing: 16,
                      childAspectRatio: cardWidth / cardHeight,
                    ),
                    itemBuilder: (context, index) {
                      final o = orders[index];
                      return _buildOrderCard(o);
                    },
                  );
                },
              );
            },
          ),
        ],
      ),
    );
  }
}

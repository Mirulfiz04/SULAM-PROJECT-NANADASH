// auth_service.dart
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/foundation.dart'; // kIsWeb
import 'dart:io' show Platform, File; // Platform.isAndroid, etc.
import 'session_manager.dart';
import 'dart:typed_data'; // 👈 add this



class AuthService {
  static String get _baseUrl {
    if (kIsWeb) {
      // Flutter Web running in browser on your PC
      return 'http://localhost/flutter_api';
    } else if (Platform.isAndroid) {
      // Android emulator
      return 'http://10.0.2.2/flutter_api';
    } else {
      // Windows / macOS / Linux desktop apps
      return 'http://localhost/flutter_api';
    }
  }

  // ========== REGISTER (name + email + password + phone + role) ==========
  static Future<Map<String, dynamic>> register(
      String name,
      String email,
      String password,
      String phone,
      String role, // 'customer' or 'admin'
      ) async {
    try {
      final url = Uri.parse('$_baseUrl/register.php');

      final response = await http
          .post(
        url,
        body: {
          'name': name,
          'email': email,
          'password': password,
          'phone': phone,
          'role': role,
        },
      )
          .timeout(const Duration(seconds: 10));

      print('REGISTER status: ${response.statusCode}');
      print('REGISTER body  : ${response.body}');

      if (response.statusCode != 200) {
        return {
          'success': false,
          'message': 'Server error: ${response.statusCode}',
        };
      }

      return jsonDecode(response.body);
    } catch (e) {
      print('REGISTER error: $e');
      return {
        'success': false,
        'message': 'Failed to connect to server. Error: $e',
      };
    }
  }

  // ========== LOGIN ==========
  static Future<Map<String, dynamic>> login(
      String email,
      String password,
      ) async {
    try {
      final url = Uri.parse('$_baseUrl/login.php');

      final response = await http
          .post(url, body: {'email': email, 'password': password})
          .timeout(const Duration(seconds: 10));

      print('LOGIN status: ${response.statusCode}');
      print('LOGIN body  : ${response.body}');

      if (response.statusCode != 200) {
        return {
          'success': false,
          'message': 'Server error: ${response.statusCode}',
        };
      }

      // Decode JSON from PHP
      final data = jsonDecode(response.body);

      // If login success, save session (id, name, role)
      if (data['success'] == true && data['user'] != null) {
        final user = data['user'];

        final session = SessionManager();
        await session.saveUserSession(
          id: int.parse(user['id'].toString()),
          name: user['name']?.toString() ?? '',
          role: user['role']?.toString() ?? '',
          email: user['email']?.toString(),   // 👈 optional but we pass it if exists
        );
      }

      return data;
    } catch (e) {
      print('LOGIN error: $e');
      return {
        'success': false,
        'message': 'Failed to connect to server. Error: $e',
      };
    }
  }

  // ========== FORGOT PASSWORD ==========
  static Future<Map<String, dynamic>> forgotPassword(
      String email,
      String newPassword,
      ) async {
    try {
      final url = Uri.parse('$_baseUrl/forgot_password.php');

      final response = await http
          .post(url, body: {'email': email, 'new_password': newPassword})
          .timeout(const Duration(seconds: 10));

      print('FORGOT PW status: ${response.statusCode}');
      print('FORGOT PW body  : ${response.body}');

      if (response.statusCode != 200) {
        return {
          'success': false,
          'message': 'Server error: ${response.statusCode}',
        };
      }

      return jsonDecode(response.body);
    } catch (e) {
      print('FORGOT PW error: $e');
      return {
        'success': false,
        'message': 'Failed to connect to server. Error: $e',
      };
    }
  }

  // ========== FORGOT EMAIL (name + phone) ==========
  static Future<Map<String, dynamic>> forgotEmail(
      String name,
      String phone,
      ) async {
    try {
      final url = Uri.parse('$_baseUrl/forgot_email.php');

      final response = await http
          .post(url, body: {'name': name, 'phone': phone})
          .timeout(const Duration(seconds: 10));

      print('FORGOT EMAIL status: ${response.statusCode}');
      print('FORGOT EMAIL body  : ${response.body}');

      if (response.statusCode != 200) {
        return {
          'success': false,
          'message': 'Server error: ${response.statusCode}',
        };
      }

      return jsonDecode(response.body);
    } catch (e) {
      print('FORGOT EMAIL error: $e');
      return {
        'success': false,
        'message': 'Failed to connect to server. Error: $e',
      };
    }
  }

  // ========== CREATE ORDER ==========
  static Future<Map<String, dynamic>> createOrder({
    required int customerId,
    required int productId,
    required int quantity,
    required double transportCost,
    required String deliveryAddress,
    String? deliveryNotes,
  }) async {
    try {
      final url = Uri.parse('$_baseUrl/create_order.php');

      final response = await http
          .post(
        url,
        body: {
          'customer_id': customerId.toString(),
          'product_id': productId.toString(),
          'quantity': quantity.toString(),
          'transport_cost': transportCost.toString(),
          'delivery_address': deliveryAddress,
          'delivery_notes': deliveryNotes ?? '',
        },
      )
          .timeout(const Duration(seconds: 10));

      print('CREATE ORDER status: ${response.statusCode}');
      print('CREATE ORDER body  : ${response.body}');

      if (response.statusCode != 200) {
        return {
          'success': false,
          'message': 'Server error: ${response.statusCode}',
        };
      }

      return jsonDecode(response.body);
    } catch (e) {
      print('CREATE ORDER error: $e');
      return {
        'success': false,
        'message': 'Failed to connect to server. Error: $e',
      };
    }
  }

  // ========== UPDATE PROFILE (name + phone) ==========
  static Future<Map<String, dynamic>> updateProfile(
      String id,
      String name,
      String phone,
      ) async {
    try {
      final url = Uri.parse('$_baseUrl/update_profile.php');

      final response = await http.post(
        url,
        body: {
          'id': id,
          'name': name,
          'phone': phone,
        },
      ).timeout(const Duration(seconds: 10));

      print('UPDATE PROFILE status: ${response.statusCode}');
      print('UPDATE PROFILE body  : ${response.body}');

      if (response.statusCode != 200) {
        return {
          'success': false,
          'message': 'Server error: ${response.statusCode}',
        };
      }

      return jsonDecode(response.body);
    } catch (e) {
      print('UPDATE PROFILE error: $e');
      return {
        'success': false,
        'message': 'Failed to connect to server. Error: $e',
      };
    }
  }

  // ========== ADMIN: GET ALL ORDERS ==========
  // Optional [status] filter so you can call:
  // AuthService.getAdminOrders(status: 'pending') if you want.
  static Future<Map<String, dynamic>> getAdminOrders({String? status}) async {
    try {
      final query = status != null ? '?status=$status' : '';
      final url = Uri.parse('$_baseUrl/get_orders.php$query');

      final response =
      await http.get(url).timeout(const Duration(seconds: 10));

      print('GET ORDERS status: ${response.statusCode}');
      print('GET ORDERS body  : ${response.body}');

      if (response.statusCode != 200) {
        return {
          'success': false,
          'message': 'Server error: ${response.statusCode}',
        };
      }

      return jsonDecode(response.body);
    } catch (e) {
      print('GET ORDERS error: $e');
      return {
        'success': false,
        'message': 'Failed to connect to server. Error: $e',
      };
    }
  }

  // ========== ADMIN: UPDATE ORDER STATUS ==========
  static Future<bool> updateOrderStatus({
    required int orderId,
    required String status, // 'accepted' or 'rejected'
    int? adminId,
  }) async {
    try {
      final url = Uri.parse('$_baseUrl/update_order_status.php');

      final response = await http.post(
        url,
        body: {
          'order_id': orderId.toString(),
          'status': status,
          if (adminId != null) 'admin_id': adminId.toString(),
        },
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode != 200) return false;

      final data = jsonDecode(response.body);
      return data['success'] == true;
    } catch (e) {
      print('UPDATE ORDER STATUS error: $e');
      return false;
    }
  }


  // ========== CUSTOMER: GET MY ORDERS ==========
  static Future<List<dynamic>> getMyOrders(int customerId) async {
    final url =
    Uri.parse('$_baseUrl/get_orders.php?customer_id=$customerId');

    try {
      final response =
      await http.get(url).timeout(const Duration(seconds: 10));

      print("GET MY ORDERS status: ${response.statusCode}");
      print("GET MY ORDERS body: ${response.body}");

      if (response.statusCode != 200) {
        return [];
      }

      final data = jsonDecode(response.body);

      // Case 1 (normal): { success: true, orders: [...] }
      if (data is Map<String, dynamic>) {
        if (data['success'] == true && data['orders'] is List) {
          return List<dynamic>.from(data['orders']);
        }
        return [];
      }

      // Case 2: API directly returns a list
      if (data is List) {
        return data;
      }

      return [];
    } catch (e) {
      print("GET MY ORDERS ERROR: $e");
      return [];
    }
  }

  /// Create news (for admin/user) with optional image.
  /// - On mobile/desktop: pass [imageFile]
  /// - On web: pass [webImageBytes]
  static Future<Map<String, dynamic>> createNews({
    required String title,
    required String content,
    String? createdBy,
    File? imageFile,            // for mobile/desktop
    Uint8List? webImageBytes,   // for web
  }) async {
    final url = Uri.parse('$_baseUrl/create_news.php');

    try {
      // --------------------------------------------------
      // 1) NO IMAGE at all → simple POST
      // --------------------------------------------------
      if (imageFile == null && webImageBytes == null) {
        final response = await http.post(
          url,
          body: {
            'title': title,
            'content': content,
            if (createdBy != null) 'created_by': createdBy,
          },
        ).timeout(const Duration(seconds: 10));

        if (response.statusCode != 200) {
          return {
            'success': false,
            'message': 'Server error: ${response.statusCode}',
          };
        }

        final data = jsonDecode(response.body);
        if (data is Map<String, dynamic>) return data;
        return {
          'success': false,
          'message': 'Unexpected response format',
        };
      }

      // --------------------------------------------------
      // 2) WITH IMAGE (File on mobile / bytes on web)
      // --------------------------------------------------
      final request = http.MultipartRequest('POST', url);
      request.fields['title'] = title;
      request.fields['content'] = content;
      if (createdBy != null) {
        request.fields['created_by'] = createdBy;
      }

      http.MultipartFile multipartFile;

      if (imageFile != null) {
        // Mobile / desktop path
        final imageBytes = await imageFile.readAsBytes();
        multipartFile = http.MultipartFile.fromBytes(
          'image',
          imageBytes,
          filename: imageFile.path.split('/').last,
        );
      } else {
        // Web path (bytes only)
        multipartFile = http.MultipartFile.fromBytes(
          'image',
          webImageBytes!,
          filename: 'news_image.png',
        );
      }

      request.files.add(multipartFile);

      final streamedResponse = await request.send();
      final response = await http.Response.fromStream(streamedResponse);

      if (response.statusCode != 200) {
        return {
          'success': false,
          'message': 'Server error: ${response.statusCode}',
        };
      }

      final data = jsonDecode(response.body);
      if (data is Map<String, dynamic>) return data;
      return {
        'success': false,
        'message': 'Unexpected response format',
      };
    } catch (e) {
      print('CREATE NEWS ERROR: $e');
      return {
        'success': false,
        'message': 'Network error: $e',
      };
    }
  }

  /// Get all news for customer/admin
  static Future<List<Map<String, dynamic>>> getNews() async {
    final url = Uri.parse('$_baseUrl/get_news.php');

    try {
      final response =
      await http.get(url).timeout(const Duration(seconds: 10));

      print('GET NEWS status: ${response.statusCode}');
      print('GET NEWS body  : ${response.body}');

      if (response.statusCode != 200) {
        return [];
      }

      final data = jsonDecode(response.body);

      // If backend returns a pure list: [ {...}, {...} ]
      if (data is List) {
        return List<Map<String, dynamic>>.from(data);
      }

      // If backend returns { "news": [ ... ] }
      if (data is Map && data['news'] is List) {
        return List<Map<String, dynamic>>.from(data['news']);
      }

      return [];
    } catch (e) {
      print('GET NEWS ERROR: $e');
      return [];
    }
  }

  // ========== PRODUCTS (for admin "OUR PRODUCT") ==========
  //boleh buang kalau tak nk

  static Future<List<Map<String, dynamic>>> getProducts() async {
    final url = Uri.parse('$_baseUrl/get_products.php');

    try {
      final response =
      await http.get(url).timeout(const Duration(seconds: 10));

      print('GET PRODUCTS status: ${response.statusCode}');
      print('GET PRODUCTS body  : ${response.body}');

      if (response.statusCode != 200) {
        return [];
      }

      final data = jsonDecode(response.body);

      // If backend returns [ {...}, {...} ]
      if (data is List) {
        return List<Map<String, dynamic>>.from(data);
      }

      // If backend returns { "products": [ ... ] }
      if (data is Map && data['products'] is List) {
        return List<Map<String, dynamic>>.from(data['products']);
      }

      return [];
    } catch (e) {
      print('GET PRODUCTS ERROR: $e');
      return [];
    }
  }

  static Future<Map<String, dynamic>> createProduct({
    required String name,
    required String description,
    required String orderCondition,
    required double unitPrice,
    File? imageFile,            // mobile/desktop
    Uint8List? webImageBytes,   // web
  }) async {
    final url = Uri.parse('$_baseUrl/create_product.php');

    try {
      // ---------- NO IMAGE: simple POST ----------
      if (imageFile == null && webImageBytes == null) {
        final response = await http.post(
          url,
          body: {
            'name': name,
            'description': description,
            'order_condition': orderCondition,
            'unit_price': unitPrice.toString(),
          },
        ).timeout(const Duration(seconds: 10));

        print('CREATE PRODUCT status: ${response.statusCode}');
        print('CREATE PRODUCT body  : ${response.body}');

        if (response.statusCode != 200) {
          return {
            'success': false,
            'message': 'Server error: ${response.statusCode}',
          };
        }

        final data = jsonDecode(response.body);
        if (data is Map<String, dynamic>) return data;

        return {
          'success': false,
          'message': 'Unexpected response format',
        };
      }

      // ---------- WITH IMAGE: multipart ----------
      final request = http.MultipartRequest('POST', url);
      request.fields['name'] = name;
      request.fields['description'] = description;
      request.fields['order_condition'] = orderCondition;
      request.fields['unit_price'] = unitPrice.toString();

      http.MultipartFile multipartFile;

      if (imageFile != null) {
        final bytes = await imageFile.readAsBytes();
        multipartFile = http.MultipartFile.fromBytes(
          'image',
          bytes,
          filename: imageFile.path.split('/').last,
        );
      } else {
        multipartFile = http.MultipartFile.fromBytes(
          'image',
          webImageBytes!,
          filename: 'product_image.png',
        );
      }

      request.files.add(multipartFile);

      final streamedResponse = await request.send();
      final response = await http.Response.fromStream(streamedResponse);

      print('CREATE PRODUCT (multipart) status: ${response.statusCode}');
      print('CREATE PRODUCT (multipart) body  : ${response.body}');

      if (response.statusCode != 200) {
        return {
          'success': false,
          'message': 'Server error: ${response.statusCode}',
        };
      }

      final data = jsonDecode(response.body);
      if (data is Map<String, dynamic>) return data;

      return {
        'success': false,
        'message': 'Unexpected response format',
      };
    } catch (e) {
      print('CREATE PRODUCT ERROR: $e');
      return {
        'success': false,
        'message': 'Network error: $e',
      };
    }
  }


}




import 'package:flutter/material.dart';
import 'admin_orders_screen.dart';
import 'session_manager.dart';
import 'auth_service.dart';
import 'main.dart';               // for LoginScreen() + MyProfileScreen()
import 'admin_news_screen.dart';
import 'admin_product_screen.dart';
import 'order_screen.dart';       // (optional; remove if unused)

/// =============================================================
/// DASHBOARD SCREEN – ADMIN HOME + DRAWER
/// =============================================================
class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  static const Color _orange = Color(0xFFF97316);
  static const Color _purple = Color(0xFF9333EA);

  String? _adminName;
  String? _adminEmail;
  String? _adminRole;

  @override
  void initState() {
    super.initState();
    _loadAdminName();
  }

  Future<void> _loadAdminName() async {
    final session = SessionManager();
    final name = await session.getUserName();
    final email = await session.getUserEmail();
    final role = await session.getUserRole();

    if (!mounted) return;
    setState(() {
      _adminName = name;
      _adminEmail = email;
      _adminRole = role;
    });
  }

  void _showAdminProfilePopup() {
    final roleLabel = (_adminRole ?? 'admin').toUpperCase();
    final name = _adminName ?? '<ADMIN NAME>';
    final email = _adminEmail ?? '<EMAIL NOT SET>';

    showDialog(
      context: context,
      barrierColor: Colors.transparent,
      builder: (dialogCtx) {
        final paddingTop = MediaQuery.of(context).padding.top;

        return Stack(
          children: [
            // tap outside to close
            Positioned.fill(
              child: GestureDetector(
                onTap: () => Navigator.pop(dialogCtx),
                child: Container(color: Colors.transparent),
              ),
            ),

            // popup card
            Positioned(
              top: paddingTop + 52,
              right: 12,
              child: Material(
                elevation: 10,
                borderRadius: BorderRadius.circular(18),
                child: Container(
                  width: 220,
                  padding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        roleLabel,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontSize: 12,
                          letterSpacing: 1.3,
                          fontWeight: FontWeight.w700,
                          color: Colors.black,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        name,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: Colors.black,
                        ),
                      ),
                      const SizedBox(height: 12),
                      Container(height: 1.5, color: _orange),
                      const SizedBox(height: 12),
                      const Text(
                        'Email',
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w500,
                          color: Colors.black54,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        email,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontSize: 13,
                          color: Colors.black,
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextButton(
                        onPressed: () {
                          Navigator.pop(dialogCtx);
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => const MyProfileScreen(),
                            ),
                          );
                        },
                        child: const Text(
                          'Edit profile',
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.bold,
                            color: Colors.black,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final bool isMobile = size.width < 600;

    return Scaffold(
      drawer: const _AdminDrawer(),
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset(
            'assets/image/HOME.png',
            fit: BoxFit.cover,
          ),
          Container(color: Colors.black.withOpacity(0.02)),

          // top bar
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: SafeArea(
              bottom: false,
              child: Column(
                children: [
                  Container(
                    height: 56,
                    color: Colors.white,
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: Row(
                      children: [
                        Builder(
                          builder: (ctx) => IconButton(
                            icon: const Icon(Icons.menu, size: 28),
                            color: _orange,
                            onPressed: () => Scaffold.of(ctx).openDrawer(),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            'Admin ${_adminName ?? '<name admin>'}',
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              color: Colors.black,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        const SizedBox(width: 8),
                        GestureDetector(
                          onTap: _showAdminProfilePopup,
                          child: const CircleAvatar(
                            radius: 18,
                            backgroundColor: Colors.white,
                            child: Icon(Icons.person, color: _orange),
                          ),
                        ),
                        const SizedBox(width: 4),
                      ],
                    ),
                  ),
                  Container(height: 3, color: _purple),
                ],
              ),
            ),
          ),

          // NANADASH logo center
          Positioned(
            top: isMobile ? 140 : 220,
            left: isMobile ? 0 : 80,
            right: isMobile ? 0 : null,
            child: Align(
              alignment:
              isMobile ? Alignment.topCenter : Alignment.centerLeft,
              child: Image.asset(
                'assets/image/NANADASH.png',
                width: isMobile ? size.width * 0.55 : size.width * 0.45,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// =============================================================
/// ADMIN DRAWER
/// =============================================================
class _AdminDrawer extends StatelessWidget {
  const _AdminDrawer();

  static const Color _orange = Color(0xFFF97316);

  @override
  Widget build(BuildContext context) {
    return Drawer(
      elevation: 0,
      backgroundColor: Colors.white,
      child: SafeArea(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _DrawerItem(
                label: 'HOME DASHBOARD',
                onTap: () {
                  Navigator.pop(context);
                },
              ),
              const SizedBox(height: 24),

              _DrawerItem(
                label: 'ORDERS',
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const AdminOrdersScreen(),
                    ),
                  );
                },
              ),
              const SizedBox(height: 24),

              _DrawerItem(
                label: 'OUR PRODUCT',
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const AdminProductScreen(),
                    ),
                  );
                },
              ),
              const SizedBox(height: 24),

              _DrawerItem(
                label: 'NEWS / ANNOUNCEMENT',
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const AdminNewsScreen(),
                    ),
                  );
                },
              ),
              const SizedBox(height: 24),

              const Spacer(),
              const Spacer(),

              InkWell(
                onTap: () async {
                  Navigator.pop(context);
                  final session = SessionManager();
                  await session.clearSession();
                  Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const LoginScreen(),
                    ),
                        (route) => false,
                  );
                },
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: const [
                    Text(
                      'LOGOUT',
                      style: TextStyle(
                        fontSize: 16,
                        letterSpacing: 1.2,
                        fontWeight: FontWeight.w700,
                        color: Colors.red,
                      ),
                    ),
                    SizedBox(height: 8),
                    Divider(thickness: 2, color: Colors.red),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Drawer Item
class _DrawerItem extends StatelessWidget {
  final String label;
  final VoidCallback onTap;

  const _DrawerItem({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(
              fontSize: 16,
              letterSpacing: 1.2,
              fontWeight: FontWeight.w700,
              color: Colors.black,
            ),
          ),
          const SizedBox(height: 8),
          Container(
            height: 2,
            width: 160,
            color: Colors.orange,
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/widget_previews.dart';
import 'package:flutter/material.dart';
import 'dashboard_screen.dart';
import 'session_manager.dart';
import 'auth_service.dart';
import 'news_screen.dart';
import 'admin_news_screen.dart';
import 'about_us_screen.dart';
import 'package:url_launcher/url_launcher.dart';


void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'NANADASH',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        useMaterial3: true,
        fontFamily: 'Roboto',
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFFACC15),
          brightness: Brightness.dark,
        ),
      ),
      home: const LandingScreen(),
    );
  }
}

// -------------------- LANDING / GENERAL DASHBOARD --------------------

class LandingScreen extends StatelessWidget {
  const LandingScreen({super.key});

  static const Color _orange = Color(0xFFF97316);
  static const Color _purple = Color(0xFF9333EA);

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final bool isMobile = size.width < 600; // phone / small tablet

    return Scaffold(
      extendBodyBehindAppBar: true,
      drawer: const _LandingDrawer(),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: Builder(
          builder: (context) => IconButton(
            icon: const Icon(Icons.menu, size: 30),
            color: _orange,
            onPressed: () => Scaffold.of(context).openDrawer(),
          ),
        ),
        actions: [
          IconButton(
            onPressed: () {
              // go to login screen when avatar tapped
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const LoginScreen()),
              );
            },
            icon: const CircleAvatar(
              radius: 18,
              backgroundColor: Colors.white,
              child: Icon(Icons.person, color: _orange),
            ),
          ),
          const SizedBox(width: 12),
        ],
      ),
      body: Stack(
        fit: StackFit.expand,
        children: [
          // 🔶 background image
          Image.asset(
            'assets/image/HOME.png',
            fit: BoxFit.cover,
          ),

          // 🔶 white top bar (header) + purple line
          Positioned(
            top: -60,
            left: 0,
            right: 0,
            child: SafeArea(
              bottom: false,
              child: Column(
                children: [
                  Container(
                    height: 60,
                    color: Colors.white.withOpacity(0.9),
                  ),
                  Container(
                    height: 3,
                    color: Colors.red,
                  ),
                ],
              ),
            ),
          ),

          // slight overlay
          Container(color: Colors.black.withOpacity(0.02)),

          // 🔶 NANADASH logo – responsive for mobile & desktop
          Positioned(
            top: isMobile ? 140 : 220,
            left: isMobile ? 0 : 80,
            right: isMobile ? 0 : null,
            child: Align(
              alignment:
              isMobile ? Alignment.topCenter : Alignment.centerLeft,
              child: Image.asset(
                'assets/image/NANADASH.png',
                width: isMobile
                    ? size.width * 0.55   // a bit bigger + centered on phone
                    : size.width * 0.45,  // original size on wide screens
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _LandingDrawer extends StatelessWidget {
  const _LandingDrawer();

  static const Color _orange = Color(0xFFF97316);

  @override
  Widget build(BuildContext context) {
    return Drawer(
      elevation: 0,
      backgroundColor: Colors.white, // 👈 make drawer itself white
      child: SafeArea(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _DrawerItem(
                label: 'HOME DASHBOARD',
                onTap: () => Navigator.pop(context),
              ),
              const SizedBox(height: 24),
              _DrawerItem(
                label: 'OUR PRODUCT',
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const OurProductPublicScreen()),
                  );
                },
              ),

              const SizedBox(height: 24),

              // 🔔 NEW – everyone can see announcements
              _DrawerItem(
                label: 'ANNOUNCEMENT',
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const NewsScreen()),
                  );
                },
              ),
              const SizedBox(height: 24),

              _DrawerItem(
                label: 'ABOUT US',
                onTap: () {
                  Navigator.pop(context); // close the drawer first
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const AboutUsScreen(),
                    ),
                  );
                },
              ),

              const Spacer(),
              TextButton.icon(
                onPressed: () {
                  Navigator.pop(context); // close drawer
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const LoginScreen()),
                  );
                },
                icon: const Icon(Icons.login, color: _orange),
                label: const Text(
                  'Login / Register',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                  color: Colors.black,   // 👈 make text black
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// -------------------- LOGIN SCREEN --------------------

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

// Preview (VS Code / Android Studio with widget_previews)
@Preview(name: 'Login – phone size', size: Size(390, 844))
Widget loginScreenPreview() => const LoginScreen();

class _LoginScreenState extends State<LoginScreen> {
  final emailC = TextEditingController();
  final passC = TextEditingController();
  bool loading = false;
  bool rememberMe = false;

  Color get _pineappleYellow => const Color(0xFFFACC15);
  Color get _pineappleGreen => const Color(0xFF14532D);

  Future<void> _login() async {
    setState(() => loading = true);
    try {
      final res = await AuthService.login(
        emailC.text.trim(),
        passC.text.trim(),
      );

      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(res['message'] ?? '')));

      if (res['success'] == true && res['user'] != null) {
        final user = Map<String, dynamic>.from(res['user']);

      // 🔹 Save to SharedPreferences
        final session = SessionManager();
        await session.saveUserSession(
          id: int.tryParse(user['id'].toString()) ?? 0,
          name: user['name']?.toString() ?? '',
          role: user['role']?.toString() ?? 'customer',
          email: user['email']?.toString() ?? '',   // 👈 IMPORTANT
        );

        final role = user['role']?.toString().toLowerCase();

        // Decide where to go
        Widget targetScreen;
        if (role == 'admin') {
          // Admin → existing DashboardScreen from dashboard_screen.dart
          targetScreen = const DashboardScreen();
        } else {
          // Default → customer dashboard UI you just built
          targetScreen = const CustomerDashboardScreen();
        }

        // Go to the dashboard and remove Login from back stack
        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (_) => targetScreen),
              (route) => false,
        );
      }

    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Unexpected error: $e')),
      );
    } finally {
      if (mounted) {
        setState(() => loading = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          // ✅ use the correct asset path
          Image.asset('assets/image/bg_mountain.png', fit: BoxFit.cover),
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  _pineappleYellow.withOpacity(0.85),
                  _pineappleGreen.withOpacity(0.95),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
          ),
          Center(
            child: SingleChildScrollView(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 420),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 28,
                    vertical: 32,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.35),
                    borderRadius: BorderRadius.circular(28),
                    border: Border.all(color: Colors.white.withOpacity(0.25)),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.55),
                        blurRadius: 40,
                        offset: const Offset(0, 24),
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(
                            Icons.local_florist_rounded,
                            size: 26,
                            color: Colors.white70,
                          ),
                          const SizedBox(width: 8),
                          Text(
                            'NANADASH',
                            style: TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                              color: _pineappleYellow,
                              letterSpacing: 1.5,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      const Text(
                        'Fresh deliveries, pineapple style.',
                        style: TextStyle(fontSize: 13, color: Colors.white70),
                      ),
                      const SizedBox(height: 24),

                      _AuthTextField(
                        controller: emailC,
                        label: 'Email',
                        icon: Icons.email_outlined,
                        keyboardType: TextInputType.emailAddress,
                      ),
                      const SizedBox(height: 18),

                      _AuthTextField(
                        controller: passC,
                        label: 'Password',
                        icon: Icons.lock_outline,
                        obscure: true,
                      ),
                      const SizedBox(height: 16),

                      Row(
                        children: [
                          Checkbox(
                            value: rememberMe,
                            onChanged: (v) =>
                                setState(() => rememberMe = v ?? false),
                            side: const BorderSide(color: Colors.white60),
                            activeColor: _pineappleYellow,
                            materialTapTargetSize:
                            MaterialTapTargetSize.shrinkWrap,
                          ),
                          const Text('Remember me'),
                          const Spacer(),
                          TextButton(
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => const ForgotPasswordScreen(),
                                ),
                              );
                            },
                            style: TextButton.styleFrom(
                              foregroundColor: Colors.white70,
                              padding: EdgeInsets.zero,
                              minimumSize: const Size(0, 0),
                            ),
                            child: const Text('Forgot password?'),
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),

                      SizedBox(
                        width: double.infinity,
                        height: 48,
                        child: ElevatedButton(
                          onPressed: loading ? null : _login,
                          style: ElevatedButton.styleFrom(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30),
                            ),
                            backgroundColor: _pineappleYellow,
                            foregroundColor: Colors.black87,
                          ),
                          child: loading
                              ? const SizedBox(
                            height: 22,
                            width: 22,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              valueColor: AlwaysStoppedAnimation(Colors.black87),
                            ),
                          )
                              : const Text(
                            'Login',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ),

// 👇 THIS GOES OUTSIDE THE BUTTON
                      const SizedBox(height: 16),

                      TextButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => const NewsScreen()),
                          );
                        },
                        child: const Text(
                          'View Announcements',
                          style: TextStyle(
                            decoration: TextDecoration.underline,
                            fontSize: 14,
                            color: Colors.white, // optional styling
                          ),
                        ),
                      ),


                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Text("Don't have an account? "),
                          GestureDetector(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => const RegisterScreen(),
                                ),
                              );
                            },
                            child: Text(
                              'Register',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: _pineappleYellow.withOpacity(0.9),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      TextButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => const ForgotEmailScreen(),
                            ),
                          );
                        },
                        child: const Text(
                          'Forgot your email?',
                          style: TextStyle(fontSize: 13, color: Colors.white70),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }



}

// -------------------- REGISTER SCREEN --------------------

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final nameC = TextEditingController();
  final emailC = TextEditingController();
  final passC = TextEditingController();
  final phoneC = TextEditingController();

  String _selectedRole = 'customer'; // 👈 NEW – default role
  bool loading = false;

  Color get _pineappleYellow => const Color(0xFFFACC15);
  Color get _pineappleGreen => const Color(0xFF14532D);

  Future<void> _register() async {
    setState(() => loading = true);
    try {
      final res = await AuthService.register(
        nameC.text.trim(),
        emailC.text.trim(),
        passC.text.trim(),
        phoneC.text.trim(),
        _selectedRole, // 👈 send role to API
      );

      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(res['message'] ?? '')));

      if (res['success'] == true) {
        Navigator.pop(context);
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Unexpected error: $e')),
      );
    } finally {
      if (mounted) {
        setState(() => loading = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset('assets/image/bg_mountain.png', fit: BoxFit.cover),
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  _pineappleYellow.withOpacity(0.85),
                  _pineappleGreen.withOpacity(0.95),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
          ),
          Center(
            child: SingleChildScrollView(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 420),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 28,
                    vertical: 32,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.35),
                    borderRadius: BorderRadius.circular(28),
                    border: Border.all(color: Colors.white.withOpacity(0.25)),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.55),
                        blurRadius: 40,
                        offset: const Offset(0, 24),
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        'Create NANADASH account',
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: _pineappleYellow,
                        ),
                      ),
                      const SizedBox(height: 24),

                      _AuthTextField(
                        controller: nameC,
                        label: 'Name',
                        icon: Icons.person_outlined,
                      ),
                      const SizedBox(height: 18),
                      _AuthTextField(
                        controller: emailC,
                        label: 'Email',
                        icon: Icons.email_outlined,
                        keyboardType: TextInputType.emailAddress,
                      ),
                      const SizedBox(height: 18),
                      _AuthTextField(
                        controller: phoneC,
                        label: 'Phone number',
                        icon: Icons.phone_android,
                        keyboardType: TextInputType.phone,
                      ),
                      const SizedBox(height: 18),

                      // 👇 NEW: role dropdown
                      DropdownButtonFormField<String>(
                        value: _selectedRole,
                        items: const [
                          DropdownMenuItem(
                            value: 'customer',
                            child: Text('Customer'),
                          ),
                          DropdownMenuItem(
                            value: 'admin',
                            child: Text('Admin'),
                          ),
                        ],
                        onChanged: (value) {
                          if (value != null) {
                            setState(() => _selectedRole = value);
                          }
                        },
                        decoration: InputDecoration(
                          labelText: 'Role',
                          prefixIcon: const Icon(Icons.person_outline),
                          filled: true,
                          fillColor: Colors.white.withOpacity(0.06),
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(30)),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(30),
                            borderSide: BorderSide(color: Colors.white.withOpacity(0.25)),
                          ),
                          focusedBorder: const OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(30)),
                            borderSide: BorderSide(color: Color(0xFFFACC15), width: 1.6),
                          ),
                        ),
                      ),
                      const SizedBox(height: 18),

                      _AuthTextField(
                        controller: passC,
                        label: 'Password',
                        icon: Icons.lock_outline,
                        obscure: true,
                      ),
                      const SizedBox(height: 24),

                      SizedBox(
                        width: double.infinity,
                        height: 48,
                        child: ElevatedButton(
                          onPressed: loading ? null : _register,
                          style: ElevatedButton.styleFrom(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30),
                            ),
                            backgroundColor: _pineappleYellow,
                            foregroundColor: Colors.black87,
                          ),
                          child: loading
                              ? const SizedBox(
                            height: 22,
                            width: 22,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              valueColor: AlwaysStoppedAnimation(
                                Colors.black87,
                              ),
                            ),
                          )
                              : const Text(
                            'Register',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text('Back to login'),
                      ),
                    ],
                  ),

                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// -------------------- FORGOT PASSWORD --------------------

class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  final emailC = TextEditingController();
  final newPassC = TextEditingController();
  bool loading = false;

  Color get _pineappleYellow => const Color(0xFFFACC15);
  Color get _pineappleGreen => const Color(0xFF14532D);

  Future<void> _submit() async {
    setState(() => loading = true);
    try {
      final res = await AuthService.forgotPassword(
        emailC.text.trim(),
        newPassC.text.trim(),
      );

      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(res['message'] ?? '')));

      if (res['success'] == true) {
        Navigator.pop(context);
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Unexpected error: $e')),
      );
    } finally {
      if (mounted) {
        setState(() => loading = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset('assets/image/bg_mountain.png', fit: BoxFit.cover),
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  _pineappleYellow.withOpacity(0.85),
                  _pineappleGreen.withOpacity(0.95),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
          ),
          Center(
            child: SingleChildScrollView(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 420),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 28,
                    vertical: 32,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.35),
                    borderRadius: BorderRadius.circular(28),
                    border: Border.all(color: Colors.white.withOpacity(0.25)),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.55),
                        blurRadius: 40,
                        offset: const Offset(0, 24),
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        'Reset password',
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: _pineappleYellow,
                        ),
                      ),
                      const SizedBox(height: 24),
                      _AuthTextField(
                        controller: emailC,
                        label: 'Registered email',
                        icon: Icons.email_outlined,
                        keyboardType: TextInputType.emailAddress,
                      ),
                      const SizedBox(height: 18),
                      _AuthTextField(
                        controller: newPassC,
                        label: 'New password',
                        icon: Icons.lock_reset_outlined,
                        obscure: true,
                      ),
                      const SizedBox(height: 24),
                      SizedBox(
                        width: double.infinity,
                        height: 48,
                        child: ElevatedButton(
                          onPressed: loading ? null : _submit,
                          style: ElevatedButton.styleFrom(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30),
                            ),
                            backgroundColor: _pineappleYellow,
                            foregroundColor: Colors.black87,
                          ),
                          child: loading
                              ? const SizedBox(
                            height: 22,
                            width: 22,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              valueColor: AlwaysStoppedAnimation(
                                Colors.black87,
                              ),
                            ),
                          )
                              : const Text(
                            'Update password',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text('Back to login'),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// -------------------- FORGOT EMAIL --------------------

class ForgotEmailScreen extends StatefulWidget {
  const ForgotEmailScreen({super.key});

  @override
  State<ForgotEmailScreen> createState() => _ForgotEmailScreenState();
}

class _ForgotEmailScreenState extends State<ForgotEmailScreen> {
  final nameC = TextEditingController();
  final phoneC = TextEditingController();
  String? foundEmail;
  bool loading = false;

  Color get _pineappleYellow => const Color(0xFFFACC15);
  Color get _pineappleGreen => const Color(0xFF14532D);

  Future<void> _search() async {
    setState(() {
      loading = true;
      foundEmail = null;
    });

    try {
      final res = await AuthService.forgotEmail(
        nameC.text.trim(),
        phoneC.text.trim(),
      );

      if (res['success'] == true && res['email'] != null) {
        setState(() {
          foundEmail = res['email'];
        });
      }

      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(res['message'] ?? '')));
    } catch (e) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Unexpected error: $e')));
    } finally {
      if (mounted) {
        setState(() => loading = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset('assets/image/bg_mountain.png', fit: BoxFit.cover),
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  _pineappleYellow.withOpacity(0.85),
                  _pineappleGreen.withOpacity(0.95),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
          ),
          Center(
            child: SingleChildScrollView(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 420),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 28,
                    vertical: 32,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.35),
                    borderRadius: BorderRadius.circular(28),
                    border: Border.all(color: Colors.white.withOpacity(0.25)),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.55),
                        blurRadius: 40,
                        offset: const Offset(0, 24),
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        'Find your email',
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: _pineappleYellow,
                        ),
                      ),
                      const SizedBox(height: 24),
                      _AuthTextField(
                        controller: nameC,
                        label: 'Name used to register',
                        icon: Icons.person_search_outlined,
                      ),
                      const SizedBox(height: 18),
                      _AuthTextField(
                        controller: phoneC,
                        label: 'Phone number used to register',
                        icon: Icons.phone_android,
                        keyboardType: TextInputType.phone,
                      ),
                      const SizedBox(height: 24),
                      SizedBox(
                        width: double.infinity,
                        height: 48,
                        child: ElevatedButton(
                          onPressed: loading ? null : _search,
                          style: ElevatedButton.styleFrom(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30),
                            ),
                            backgroundColor: _pineappleYellow,
                            foregroundColor: Colors.black87,
                          ),
                          child: loading
                              ? const SizedBox(
                            height: 22,
                            width: 22,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              valueColor: AlwaysStoppedAnimation(
                                Colors.black87,
                              ),
                            ),
                          )
                              : const Text(
                            'Search email',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      if (foundEmail != null) ...[
                        const Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                            'Email linked to this name & phone:',
                            style: TextStyle(
                              fontWeight: FontWeight.w600,
                              color: Colors.white70,
                            ),
                          ),
                        ),
                        const SizedBox(height: 6),
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.35),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(foundEmail!),
                        ),
                        const SizedBox(height: 8),
                      ],
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text('Back to login'),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// -------------------- REUSABLE TEXT FIELD --------------------

class _AuthTextField extends StatefulWidget {
  final TextEditingController controller;
  final String label;
  final IconData icon;
  final bool obscure;
  final TextInputType? keyboardType;

  const _AuthTextField({
    required this.controller,
    required this.label,
    required this.icon,
    this.obscure = false,
    this.keyboardType,
    super.key,
  });

  @override
  State<_AuthTextField> createState() => _AuthTextFieldState();
}

class _AuthTextFieldState extends State<_AuthTextField> {
  bool _isObscured = true;

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: widget.controller,
      obscureText: widget.obscure ? _isObscured : false,
      keyboardType: widget.keyboardType,
      decoration: InputDecoration(
        labelText: widget.label,
        prefixIcon: Icon(widget.icon),
        suffixIcon: widget.obscure
            ? IconButton(
          icon: Icon(
            _isObscured ? Icons.visibility_off : Icons.visibility,
            color: Colors.white70,
          ),
          onPressed: () {
            setState(() => _isObscured = !_isObscured);
          },
        )
            : null,
        filled: true,
        fillColor: Colors.white.withOpacity(0.06),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(30)),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(30),
          borderSide: BorderSide(color: Colors.white.withOpacity(0.25)),
        ),
        focusedBorder: const OutlineInputBorder(
          borderRadius: BorderRadius.all(Radius.circular(30)),
          borderSide: BorderSide(color: Color(0xFFFACC15), width: 1.6),
        ),
      ),
    );
  }
}
// -------------------- CUSTOMER DASHBOARD --------------------

class CustomerDashboardScreen extends StatefulWidget {
  const CustomerDashboardScreen({super.key});

  @override
  State<CustomerDashboardScreen> createState() =>
      _CustomerDashboardScreenState();
}

class _CustomerDashboardScreenState extends State<CustomerDashboardScreen> {
  static const Color _orange = Color(0xFFF97316);
  static const Color _purple = Color(0xFF9333EA);

  String? _customerName;
  String? _customerRole;
  String? _customerEmail;

  @override
  void initState() {
    super.initState();
    _loadCustomerData();
  }

  Future<void> _loadCustomerData() async {
    final session = SessionManager();
    final name = await session.getUserName();
    final role = await session.getUserRole();
    final email = await session.getUserEmail();

    setState(() {
      _customerName = name;
      _customerRole = role;
      _customerEmail = email;
    });
  }

  // 🔽 POPUP CARD UNDER AVATAR
  void _showProfilePopup() {
    final roleLabel = (_customerRole ?? 'customer').toUpperCase();
    final name = _customerName ?? '<NAME>';
    final email = _customerEmail ?? '<EMAIL NOT SET>';

    showDialog(
      context: context,
      barrierColor: Colors.transparent,
      builder: (dialogCtx) {
        final paddingTop = MediaQuery.of(context).padding.top;

        return Stack(
          children: [
            // tap outside to close
            Positioned.fill(
              child: GestureDetector(
                onTap: () => Navigator.pop(dialogCtx),
                child: Container(color: Colors.transparent),
              ),
            ),

            // white card under avatar
            Positioned(
              top: paddingTop + 52,
              right: 12,
              child: Material(
                elevation: 10,
                borderRadius: BorderRadius.circular(18),
                child: Container(
                  width: 220,
                  padding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // <ROLES>
                      Text(
                        roleLabel,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontSize: 12,
                          letterSpacing: 1.3,
                          fontWeight: FontWeight.w700,
                          color: Colors.black,
                        ),
                      ),
                      const SizedBox(height: 8),

                      // <NAME>
                      Text(
                        name,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: Colors.black,
                        ),
                      ),
                      const SizedBox(height: 12),

                      // orange line
                      Container(
                        height: 1.5,
                        color: _orange,
                      ),
                      const SizedBox(height: 12),

                      // <EMAIL>
                      const Text(
                        'Email',
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w500,
                          color: Colors.black54,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        email,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontSize: 13,
                          color: Colors.black,
                        ),
                      ),
                      const SizedBox(height: 12),

                      // <EDIT PROFILE>
                      TextButton(
                        onPressed: () {
                          Navigator.pop(dialogCtx);
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => const MyProfileScreen(),
                            ),
                          );
                        },
                        child: const Text(
                          'Edit profile',
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.bold,
                            color: Colors.black,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final bool isMobile = size.width < 600; // phone / small tablet

    return Scaffold(
      drawer: const _CustomerDrawer(),
      body: Stack(
        fit: StackFit.expand,
        children: [
          // background
          Image.asset(
            'assets/image/HOME.png',
            fit: BoxFit.cover,
          ),
          Container(color: Colors.black.withOpacity(0.02)),

          // top bar
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: SafeArea(
              bottom: false,
              child: Column(
                children: [
                  Container(
                    height: 56,
                    color: Colors.white,
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: Row(
                      children: [
                        Builder(
                          builder: (ctx) => IconButton(
                            icon: const Icon(Icons.menu, size: 28),
                            color: _orange,
                            onPressed: () => Scaffold.of(ctx).openDrawer(),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            'Hello ${_customerName ?? 'customer'}.',
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              color: Colors.black,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        const SizedBox(width: 8),

                        // avatar -> popup
                        GestureDetector(
                          onTap: _showProfilePopup,
                          child: const CircleAvatar(
                            radius: 18,
                            backgroundColor: Colors.white,
                            child: Icon(Icons.person, color: _orange),
                          ),
                        ),
                        const SizedBox(width: 4),
                      ],
                    ),
                  ),
                  Container(height: 3, color: _purple),
                ],
              ),
            ),
          ),

          // NANADASH logo
          PositionedFillLogo(isMobile: isMobile, size: size),
        ],

      ),
    );
  }
}




// small helper to keep logo code clean
class PositionedFillLogo extends StatelessWidget {
  final bool isMobile;
  final Size size;

  const PositionedFillLogo({
    super.key,
    required this.isMobile,
    required this.size,
  });

  @override
  Widget build(BuildContext context) {
    return Positioned.fill(
      top: 80,
      child: Align(
        alignment: isMobile ? Alignment.topCenter : Alignment.centerLeft,
        child: Padding(
          padding: EdgeInsets.only(
            left: isMobile ? 0 : 80,
            top: isMobile ? 40 : 0,
          ),
          child: Image.asset(
            'assets/image/nanadash.png',
            width: isMobile ? size.width * 0.55 : size.width * 0.40,
          ),
        ),
      ),
    );
  }
}

class _CustomerDrawer extends StatelessWidget {
  const _CustomerDrawer();

  static const Color _orange = Color(0xFFF97316);

  @override
  Widget build(BuildContext context) {
    return Drawer(
      elevation: 0,
      backgroundColor: Colors.white, //
      child: SafeArea(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),

          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _DrawerItem(
                label: 'HOME DASHBOARD',
                onTap: () {
                  Navigator.pop(context); // already on home
                },
              ),
              const SizedBox(height: 24),

              _DrawerItem(
                label: 'MAKE ORDER',
                onTap: () {
                  Navigator.pop(context); // close drawer
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const MakeOrderScreen(),
                    ),
                  );
                },
              ),
              const SizedBox(height: 24),

              _DrawerItem(
                label: 'VIEW MY ORDER',
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const ViewMyOrderScreen(),
                    ),
                  );
                },
              ),
              const SizedBox(height: 24),

              // 👇 ADD NEWS ITEM HERE
              _DrawerItem(
                label: 'NEWS & ANNOUNCEMENT',
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const NewsScreen(),
                    ),
                  );
                },
              ),
              const SizedBox(height: 24),

              _DrawerItem(
                label: 'MY PROFILE',
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const MyProfileScreen(),
                    ),
                  );
                },
              ),

              const Spacer(),
              // 🔥 LOGOUT BUTTON ADDED HERE
              TextButton.icon(
                onPressed: () async {
                  Navigator.pop(context); // close drawer first

                  // clear session
                  final session = SessionManager();
                  await session.clearSession();

                  // go to login and remove all previous routes
                  Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(builder: (_) => const LoginScreen()),
                        (route) => false,
                  );
                },
                icon: const Icon(Icons.logout, color: Colors.black),
                label: const Text(
                  'Logout',
                  style: TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _DrawerItem extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  static const Color _orange = Color(0xFFF97316);

  const _DrawerItem({
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(
              fontSize: 16,
              letterSpacing: 1.2,
              fontWeight: FontWeight.w700,
              color: Colors.black,
            ),
          ),
          const SizedBox(height: 8),
          Container(
            height: 2,
            width: 160,
            color: _orange,
          ),
        ],
      ),
    );
  }
}


// -------------------- HOME + EDIT PROFILE --------------------

class HomeScreen extends StatelessWidget {
  final Map<String, dynamic> user;

  const HomeScreen({super.key, required this.user});

  Color get _pineappleYellow => const Color(0xFFFACC15);
  Color get _pineappleGreen => const Color(0xFF14532D);

  @override
  Widget build(BuildContext context) {
    final name = user['name'] ?? 'NANADASH rider';

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text('NANADASH'),
        actions: [
          IconButton(
            icon: const Icon(Icons.person),
            tooltip: 'Edit profile',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => EditProfileScreen(user: user),
                ),
              );
            },
          ),
        ],
      ),
      extendBodyBehindAppBar: true,
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset('assets/image/bg_mountain.png', fit: BoxFit.cover),
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  _pineappleYellow.withOpacity(0.85),
                  _pineappleGreen.withOpacity(0.95),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
          ),
          Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'Welcome, $name!',
                  style: const TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Ready to deliver some fresh orders? 🍍',
                  style: TextStyle(fontSize: 14, color: Colors.white70),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class EditProfileScreen extends StatefulWidget {
  final Map<String, dynamic> user;

  const EditProfileScreen({super.key, required this.user});

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  late TextEditingController nameC;
  late TextEditingController phoneC;
  late String email;
  bool loading = false;

  Color get _pineappleYellow => const Color(0xFFFACC15);
  Color get _pineappleGreen => const Color(0xFF14532D);

  @override
  void initState() {
    super.initState();
    nameC = TextEditingController(text: widget.user['name'] ?? '');
    phoneC = TextEditingController(text: widget.user['phonenumber'] ?? widget.user['phone'] ?? '');
    email = widget.user['email'] ?? '';
  }

  @override
  void dispose() {
    nameC.dispose();
    phoneC.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final id = widget.user['id']?.toString() ?? '';
    if (id.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('User ID missing, please re-login.')),
      );
      return;
    }

    setState(() => loading = true);
    try {
      final res = await AuthService.updateProfile(
        id,
        nameC.text.trim(),
        phoneC.text.trim(),
      );

      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(res['message'] ?? '')));

      if (res['success'] == true) {
        Navigator.pop(context);
      }
    } catch (e) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Unexpected error: $e')));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset('assets/image/bg_mountain.png', fit: BoxFit.cover),
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  _pineappleYellow.withOpacity(0.85),
                  _pineappleGreen.withOpacity(0.95),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
          ),
          Center(
            child: SingleChildScrollView(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 420),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 28,
                    vertical: 32,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.35),
                    borderRadius: BorderRadius.circular(28),
                    border: Border.all(color: Colors.white.withOpacity(0.25)),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.55),
                        blurRadius: 40,
                        offset: const Offset(0, 24),
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        'Edit profile',
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: _pineappleYellow,
                        ),
                      ),
                      const SizedBox(height: 24),
                      _AuthTextField(
                        controller: nameC,
                        label: 'Name',
                        icon: Icons.person_outline,
                      ),
                      const SizedBox(height: 18),
                      // email shown but not editable
                      TextField(
                        enabled: false,
                        controller: TextEditingController(text: email),
                        decoration: const InputDecoration(
                          labelText: 'Email',
                          prefixIcon: Icon(Icons.email_outlined),
                        ),
                      ),
                      const SizedBox(height: 18),
                      _AuthTextField(
                        controller: phoneC,
                        label: 'Phone number',
                        icon: Icons.phone_android,
                        keyboardType: TextInputType.phone,
                      ),
                      const SizedBox(height: 24),
                      SizedBox(
                        width: double.infinity,
                        height: 48,
                        child: ElevatedButton(
                          onPressed: loading ? null : _save,
                          style: ElevatedButton.styleFrom(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30),
                            ),
                            backgroundColor: _pineappleYellow,
                            foregroundColor: Colors.black87,
                          ),
                          child: loading
                              ? const SizedBox(
                            height: 22,
                            width: 22,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              valueColor: AlwaysStoppedAnimation(
                                Colors.black87,
                              ),
                            ),
                          )
                              : const Text(
                            'Save changes',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text('Back'),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
// -------------------- MAKE ORDER SCREEN (NEW UI + OLD LOGIC) --------------------

class MakeOrderScreen extends StatefulWidget {
  const MakeOrderScreen({super.key});

  @override
  State<MakeOrderScreen> createState() => _MakeOrderScreenState();
}

class _MakeOrderScreenState extends State<MakeOrderScreen> {
  static const Color _orange = Color(0xFFF97316);
  static const Color _purple = Color(0xFF9333EA);

  // === old pricing data ===
  static const double _priceBuahSegar = 3.50;      // RM per kg
  static const double _priceAnakPokok = 0.25;      // RM per anak pokok
  static const int _minOrderAnakPokok = 10000;
  static const double _taxRate = 0.06;             // 6%

  // product & transport selection
  int _productId = 1;               // 1 = buah segar, 2 = anak pokok
  double _transportCost = 150.0;    // default Lori 1 Tan

  // controllers
  final _nameC = TextEditingController();
  final _phoneC = TextEditingController();
  final _qtyC = TextEditingController();
  final _addressC = TextEditingController();
  final _notesC = TextEditingController();

  // totals
  double _subtotal = 0;
  double _tax = 0;
  double _total = 0;

  final _formKey = GlobalKey<FormState>();

  String? _customerName;

  @override
  void initState() {
    super.initState();
    _loadCustomerName();
  }

  Future<void> _loadCustomerName() async {
    final session = SessionManager();
    final name = await session.getUserName();
    setState(() {
      _customerName = name;
      if (name != null && name.isNotEmpty) {
        _nameC.text = name;
      }
    });
  }

  @override
  void dispose() {
    _nameC.dispose();
    _phoneC.dispose();
    _qtyC.dispose();
    _addressC.dispose();
    _notesC.dispose();
    super.dispose();
  }

  // === old recalc logic, reused ===
  void _recalculate() {
    final qty = int.tryParse(_qtyC.text.trim()) ?? 0;
    final unitPrice =
    _productId == 1 ? _priceBuahSegar : _priceAnakPokok; // RM per unit

    final subtotal = unitPrice * qty;
    final tax = subtotal * _taxRate;
    final total = subtotal + tax + _transportCost;

    setState(() {
      _subtotal = subtotal;
      _tax = tax;
      _total = total;
    });
  }

  // === old submit logic, reused with new UI ===
  Future<void> _submitOrder() async {
    if (!_formKey.currentState!.validate()) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please complete required fields.')),
      );
      return;
    }

    final qty = int.tryParse(_qtyC.text.trim()) ?? 0;

    if (_productId == 2 && qty < _minOrderAnakPokok) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Minimum order untuk Anak Pokok ialah $_minOrderAnakPokok anak pokok.',
          ),
        ),
      );
      return;
    }

    // get customer from session
    final session = SessionManager();
    final idStr = await session.getUserId();
    final role = await session.getUserRole();

    if (idStr == null || role != 'customer') {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Anda perlu login sebagai customer untuk buat order.'),
        ),
      );
      return;
    }

    final customerId = int.tryParse(idStr) ?? 0;
    if (customerId <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('ID customer tidak sah. Sila login semula.'),
        ),
      );
      return;
    }

    // loading dialog
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()),
    );

    final res = await AuthService.createOrder(
      customerId: customerId,
      productId: _productId == 1 ? 1 : 2, // must match your DB products
      quantity: qty,
      transportCost: _transportCost,
      deliveryAddress: _addressC.text.trim(),
      deliveryNotes: _notesC.text.trim(),
    );

    Navigator.pop(context); // close loading

    if (res['success'] == true) {
      final totalFromApi = res['total_amount'] ?? _total;
      final totalDouble = double.tryParse(totalFromApi.toString()) ?? _total;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Order berjaya! Jumlah: RM ${totalDouble.toStringAsFixed(2)}',
          ),
        ),
      );

      setState(() {
        _qtyC.clear();
        _addressC.clear();
        _notesC.clear();
        _subtotal = 0;
        _tax = 0;
        _total = 0;
      });
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(res['message'] ?? 'Gagal membuat order.'),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          // 🔶 Canva-style background
          Image.asset(
            'assets/image/NANADASH_2.png',
            fit: BoxFit.cover,
          ),
          Container(color: Colors.black.withOpacity(0.12)),

          SafeArea(
            child: Column(
              children: [
                // 🔶 top white bar
                Container(
                  height: 60,
                  color: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  child: Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.arrow_back),
                        color: _orange,
                        onPressed: () => Navigator.pop(context),
                      ),
                      const SizedBox(width: 4),
                      Expanded(
                        child: Text(
                          'Hello ${_customerName ?? '<name customer>'}.',
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Colors.black,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      const SizedBox(width: 8),
                      GestureDetector(
                        onTap: _submitOrder,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 24,
                            vertical: 10,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(30),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.20),
                                blurRadius: 10,
                                offset: const Offset(0, 4),
                              ),
                            ],
                          ),
                          child: const Text(
                            'SUBMIT ORDER',
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w700,
                              color: Colors.black,
                              letterSpacing: 1.2,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                    ],
                  ),
                ),
                Container(height: 3, color: _purple),

                // 🔶 main content
                Expanded(
                  child: Center(
                    child: SingleChildScrollView(
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 820),
                        child: Column(
                          children: [
                            // white card
                            Container(
                              margin: const EdgeInsets.all(24),
                              padding: const EdgeInsets.symmetric(
                                horizontal: 32,
                                vertical: 28,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(32),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.30),
                                    blurRadius: 30,
                                    offset: const Offset(0, 20),
                                  ),
                                ],
                              ),
                              child: Form(
                                key: _formKey,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    const Center(
                                      child: Text(
                                        'MAKE ORDER',
                                        style: TextStyle(
                                          fontSize: 26,
                                          fontWeight: FontWeight.w900,
                                          letterSpacing: 2,
                                          color: Colors.black,
                                        ),
                                      ),
                                    ),
                                    const SizedBox(height: 24),

// PRODUCT
                                    _fieldLabel('Product'),
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 16),
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(40),
                                        border: Border.all(            // 👈 FIX: use Border.all, not BorderSide
                                          color: _orange,
                                          width: 2,
                                        ),
                                        color: Colors.white,
                                      ),
                                      child: DropdownButtonHideUnderline(
                                        child: DropdownButton<int>(
                                          value: _productId,
                                          isExpanded: true,
                                          dropdownColor: Colors.white, // white popup background
                                          style: const TextStyle(color: Colors.black, fontSize: 16),
                                          items: const [
                                            DropdownMenuItem(
                                              value: 1,
                                              child: Text(
                                                'Buah Nanas Segar (kg)',
                                                style: TextStyle(color: Colors.black),
                                              ),
                                            ),
                                            DropdownMenuItem(
                                              value: 2,
                                              child: Text(
                                                'Anak Pokok Nanas (min 10k)',
                                                style: TextStyle(color: Colors.black),
                                              ),
                                            ),
                                          ],
                                          onChanged: (val) {
                                            setState(() => _productId = val ?? 1);
                                            _recalculate();
                                          },
                                        ),
                                      ),
                                    ),
                                    const SizedBox(height: 14),
// QUANTITY
                                    _fieldLabel('Quantity'),
                                    TextFormField(
                                      controller: _qtyC,
                                      keyboardType: TextInputType.number,
                                      style: const TextStyle(color: Colors.black),
                                      decoration: _pillDecoration().copyWith(
                                        hintText: _productId == 1 ? 'Jumlah kg' : 'Jumlah anak pokok',
                                      ),
                                      validator: (v) =>
                                      (int.tryParse(v ?? '') ?? 0) <= 0 ? 'Please enter quantity' : null,
                                      onChanged: (_) => _recalculate(),
                                    ),
                                    if (_productId == 2) ...[
                                      const SizedBox(height: 4),
                                      const Text(
                                        'Minimum order: 10000 anak pokok',
                                        style: TextStyle(color: Colors.redAccent, fontSize: 11),
                                      ),
                                    ],
                                    const SizedBox(height: 14),

// TRANSPORT
                                    _fieldLabel('Transport Type'),
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 16),
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(40),
                                        border: Border.all(
                                          color: _orange,
                                          width: 2,
                                        ),
                                        color: Colors.white,
                                      ),
                                      child: DropdownButtonHideUnderline(
                                        child: DropdownButton<double>(
                                          value: _transportCost,
                                          isExpanded: true,
                                          dropdownColor: Colors.white, // white popup background
                                          style: const TextStyle(color: Colors.black, fontSize: 16),
                                          items: const [
                                            DropdownMenuItem(
                                              value: 150.0,
                                              child: Text(
                                                'Lori 1 Tan – RM150',
                                                style: TextStyle(color: Colors.black),
                                              ),
                                            ),
                                            DropdownMenuItem(
                                              value: 250.0,
                                              child: Text(
                                                'Lori 3 Tan – RM250',
                                                style: TextStyle(color: Colors.black),
                                              ),
                                            ),
                                          ],
                                          onChanged: (val) {
                                            setState(() => _transportCost = val ?? 150.0);
                                            _recalculate();
                                          },
                                        ),
                                      ),
                                    ),
                                    const SizedBox(height: 14),

// ADDRESS
                                    _fieldLabel('Delivery address (Required)'),
                                    TextFormField(
                                      controller: _addressC,
                                      maxLines: 2,
                                      decoration: _pillDecoration(multiline: true),
                                      style: const TextStyle(color: Colors.black),
                                      validator: (v) =>
                                      v == null || v.trim().isEmpty ? 'Please enter delivery address' : null,
                                    ),
                                    const SizedBox(height: 14),

// NOTES
                                    _fieldLabel('Notes to Seller (Required)'),
                                    TextFormField(
                                      controller: _notesC,
                                      maxLines: 2,
                                      decoration: _pillDecoration(multiline: true),
                                      style: const TextStyle(color: Colors.black),
                                      validator: (v) =>
                                      v == null || v.trim().isEmpty ? 'Please enter notes to seller' : null,
                                    ),
                                  ],
                                ),
                              ),
                            ),

                            // price breakdown card
                            Card(
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(16),
                              ),
                              elevation: 6,
                              child: Padding(
                                padding: const EdgeInsets.all(16.0),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const Text(
                                      'Price Breakdown',
                                      style: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    const SizedBox(height: 8),
                                    _priceRow('Subtotal',
                                        'RM ${_subtotal.toStringAsFixed(2)}'),
                                    _priceRow('Tax (6%)',
                                        'RM ${_tax.toStringAsFixed(2)}'),
                                    _priceRow('Transport',
                                        'RM ${_transportCost.toStringAsFixed(2)}'),
                                    const Divider(),
                                    _priceRow(
                                      'Total',
                                      'RM ${_total.toStringAsFixed(2)}',
                                      isBold: true,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            const SizedBox(height: 24),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ===== UI helpers =====

  Widget _fieldLabel(String text) {
    return Padding(
      padding: const EdgeInsets.only(left: 4, bottom: 4),
      child: Text(
        text,
        style: const TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w700,
          color: Colors.black,
        ),
      ),
    );
  }

  InputDecoration _pillDecoration({bool multiline = false}) {
    return InputDecoration(
      isDense: true,
      contentPadding: EdgeInsets.symmetric(
        horizontal: 20,
        vertical: multiline ? 14 : 10,
      ),
      filled: true,
      fillColor: Colors.white,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(40),
        borderSide: const BorderSide(color: _orange, width: 2),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(40),
        borderSide: const BorderSide(color: _orange, width: 2),
      ),
      focusedBorder: const OutlineInputBorder(
        borderRadius: BorderRadius.all(Radius.circular(40)),
        borderSide: BorderSide(color: _orange, width: 2.4),
      ),
    );
  }

  Widget _priceRow(String label, String value, {bool isBold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(
              fontWeight: isBold ? FontWeight.bold : FontWeight.normal,
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontWeight: isBold ? FontWeight.bold : FontWeight.normal,
            ),
          ),
        ],
      ),
    );
  }
}


// -------------------- VIEW MY ORDER SCREEN --------------------
class ViewMyOrderScreen extends StatefulWidget {
  const ViewMyOrderScreen({super.key});

  @override
  State<ViewMyOrderScreen> createState() => _ViewMyOrderScreenState();
}

class _ViewMyOrderScreenState extends State<ViewMyOrderScreen> {
  static const Color _orange = Color(0xFFF97316);
  static const Color _purple = Color(0xFF9333EA);

  List<dynamic> _orders = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadOrders();
  }

  Future<void> _loadOrders() async {
    final session = SessionManager();
    final idStr = await session.getUserId();

    if (idStr == null) {
      setState(() {
        _orders = [];
        _loading = false;
      });
      return;
    }

    final customerId = int.tryParse(idStr) ?? 0;
    if (customerId <= 0) {
      setState(() {
        _orders = [];
        _loading = false;
      });
      return;
    }

    final list = await AuthService.getMyOrders(customerId);

    setState(() {
      _orders = list;
      _loading = false;
    });
  }

  Color _statusColor(String s) {
    switch (s) {
      case 'accepted':
        return Colors.green;
      case 'rejected':
        return Colors.red;
      default:
        return Colors.orange;
    }
  }

  String _statusLabel(String s) {
    switch (s) {
      case 'accepted':
        return 'Accepted';
      case 'rejected':
        return 'Rejected';
      default:
        return 'Pending';
    }
  }

  Widget _buildOrderCard(Map<String, dynamic> o) {
    final status = (o['status'] ?? 'pending').toString();
    final orderId = o['order_id']?.toString() ?? '-';
    final productName =
        o['product_name']?.toString() ?? 'Unknown product';
    final quantity = o['quantity']?.toString() ?? '-';
    final orderDate = o['order_date']?.toString() ?? '-';
    final acceptedAt = o['accepted_at']?.toString();
    final deliveryAddr = o['delivery_address']?.toString() ??
        o['delivery_address']?.toString() ??
        '-';

    final totalAmount =
        (o['total_amount'] ?? o['total'])?.toString() ?? '0.00';
    final subtotal = (o['subtotal'] ?? '').toString();
    final transportCost =
    (o['transport_cost'] ?? '').toString();

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.94),
        borderRadius: BorderRadius.circular(22),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.12),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Top row: Order ID + Status chip
          Row(
            children: [
              Expanded(
                child: Text(
                  'Order #$orderId',
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                    color: Colors.black,                 // ⬅ black
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: _statusColor(status).withOpacity(0.16),
                  borderRadius: BorderRadius.circular(18),
                ),
                child: Text(
                  _statusLabel(status),
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                    color: _statusColor(status),          // keep coloured text
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),

          // Product + quantity
          Text(
            productName,
            style: const TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w700,
              color: Colors.black,                       // ⬅ black
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'Quantity: $quantity',
            style: const TextStyle(
              fontSize: 13,
              color: Colors.black87,                     // ⬅ dark black
            ),
          ),
          const SizedBox(height: 8),

          // Dates
          Row(
            children: [
              const Icon(Icons.schedule,
                  size: 16, color: Colors.black54),
              const SizedBox(width: 4),
              Expanded(
                child: Text(
                  'Requested: $orderDate',
                  style: const TextStyle(
                    fontSize: 12,
                    color: Colors.black87,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 2),
          Row(
            children: [
              const Icon(Icons.check_circle_outline,
                  size: 16, color: Colors.black54),
              const SizedBox(width: 4),
              Expanded(
                child: Text(
                  status == 'accepted'
                      ? 'Accepted: ${acceptedAt ?? '-'}'
                      : status == 'rejected'
                      ? 'Rejected: ${acceptedAt ?? '-'}'
                      : 'Accepted: -',
                  style: const TextStyle(
                    fontSize: 12,
                    color: Colors.black87,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),

          // Delivery address
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Icon(Icons.location_on_outlined,
                  size: 16, color: Colors.black54),
              const SizedBox(width: 4),
              Expanded(
                child: Text(
                  deliveryAddr,
                  style: const TextStyle(
                    fontSize: 12,
                    color: Colors.black87,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),

          const Divider(color: Colors.black12),

          // Totals row
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (subtotal.isNotEmpty)
                    Text(
                      'Subtotal: RM $subtotal',
                      style: const TextStyle(
                        fontSize: 12,
                        color: Colors.black87,
                      ),
                    ),
                  if (transportCost.isNotEmpty)
                    Text(
                      'Transport: RM $transportCost',
                      style: const TextStyle(
                        fontSize: 12,
                        color: Colors.black87,
                      ),
                    ),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  const Text(
                    'Total',
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.black54,
                    ),
                  ),
                  Text(
                    'RM $totalAmount',
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w800,
                      color: Colors.black,               // ⬅ black
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset("assets/image/NANADASH_2.png", fit: BoxFit.cover),
          Container(color: Colors.black.withOpacity(0.05)),

          SafeArea(
            child: Column(
              children: [
                // TOP BAR
                Container(
                  height: 56,
                  color: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  child: Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.arrow_back),
                        color: _orange,
                        onPressed: () => Navigator.pop(context),
                      ),
                      const SizedBox(width: 8),
                      const Text(
                        'My Orders',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                          color: Colors.black,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(height: 3, color: _purple),

                Expanded(
                  child: _loading
                      ? const Center(child: CircularProgressIndicator())
                      : Padding(
                    padding: const EdgeInsets.all(16),
                    child: LayoutBuilder(
                      builder: (context, constraints) {
                        final width = constraints.maxWidth;

                        // 🔥 Responsive aspect ratio
                        double aspect;
                        if (width >= 1400) {
                          aspect = 3.8;   // very wide window → shorter cards
                        } else if (width >= 1000) {
                          aspect = 3.2;   // normal desktop
                        } else if (width >= 700) {
                          aspect = 2.2;   // tablet / small landscape
                        } else {
                          aspect = 1.05;  // phone size
                        }

                        return GridView.builder(
                          itemCount: _orders.length,
                          gridDelegate:
                          SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2,
                            crossAxisSpacing: 14,
                            mainAxisSpacing: 14,
                            childAspectRatio: aspect,
                          ),
                          itemBuilder: (_, index) {
                            final o = _orders[index] as Map<String, dynamic>;
                            return _buildOrderCard(o);
                          },
                        );
                      },
                    ),
                  ),
                ),

              ],
            ),
          ),
        ],
      ),
    );
  }
}


// -------------------- MY PROFILE SCREEN --------------------

class MyProfileScreen extends StatefulWidget {
  const MyProfileScreen({super.key});

  @override
  State<MyProfileScreen> createState() => _MyProfileScreenState();
}

class _MyProfileScreenState extends State<MyProfileScreen> {
  static const Color _orange = Color(0xFFF97316);
  static const Color _purple = Color(0xFF9333EA);

  final _nameC = TextEditingController();
  final _phoneC = TextEditingController();

  String? _userId;
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _loadFromSession();
  }

  Future<void> _loadFromSession() async {
    final session = SessionManager();
    final name = await session.getUserName();
    final id = await session.getUserId();
    setState(() {
      _nameC.text = name ?? '';
      _userId = id;
    });
  }

  Future<void> _saveProfile() async {
    if (_userId == null || _userId!.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('User ID missing, please re-login.')),
      );
      return;
    }

    setState(() => _loading = true);
    try {
      final res = await AuthService.updateProfile(
        _userId!,
        _nameC.text.trim(),
        _phoneC.text.trim(),
      );
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(res['message'] ?? 'Profile updated.')),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Unexpected error: $e')),
      );
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  void dispose() {
    _nameC.dispose();
    _phoneC.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset('assets/image/HOME.png', fit: BoxFit.cover),
          Container(color: Colors.black.withOpacity(0.05)),

          SafeArea(
            child: Column(
              children: [
                // top bar
                Container(
                  height: 56,
                  color: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  child: Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.arrow_back),
                        color: _orange,
                        onPressed: () => Navigator.pop(context),
                      ),
                      const SizedBox(width: 8),
                      const Text(
                        'My Profile',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                          color: Colors.black,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(height: 3, color: _purple),

                Expanded(
                  child: Center(
                    child: SingleChildScrollView(
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 420),
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 20, vertical: 24),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.95),
                            borderRadius: BorderRadius.circular(24),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.20),
                                blurRadius: 20,
                                offset: const Offset(0, 12),
                              ),
                            ],
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(Icons.person_pin_circle,
                                  size: 48, color: _orange),
                              const SizedBox(height: 12),
                              const Text(
                                'Update your details',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black,
                                ),
                              ),
                              const SizedBox(height: 20),

                              TextField(
                                controller: _nameC,
                                style: const TextStyle(color: Colors.black),
                                decoration: InputDecoration(
                                  labelText: 'Name',
                                  labelStyle: const TextStyle(color: Colors.black87),
                                   prefixIcon: const Icon(Icons.person_outline, color: Colors.black87),
                                  enabledBorder: const UnderlineInputBorder(
                                    borderSide: BorderSide(color: Colors.black54),
                                  ),
                                  focusedBorder: const UnderlineInputBorder(
                                    borderSide: BorderSide(color: Colors.black),
                                  ),
                                ),
                              ),
                              const SizedBox(height: 16),
                              TextField(
                                controller: _phoneC,
                                keyboardType: TextInputType.phone,
                                style: const TextStyle(color: Colors.black),
                                decoration: InputDecoration(
                                  labelText: 'Phone number',
                                  labelStyle: const TextStyle(color: Colors.black87),
                                  prefixIcon: const Icon(Icons.phone_android, color: Colors.black87),
                                  enabledBorder: const UnderlineInputBorder(
                                    borderSide: BorderSide(color: Colors.black54),
                                  ),
                                  focusedBorder: const UnderlineInputBorder(
                                    borderSide: BorderSide(color: Colors.black),
                                  ),
                                ),
                              ),
                              const SizedBox(height: 24),

                              SizedBox(
                                width: double.infinity,
                                height: 46,
                                child: ElevatedButton(
                                  onPressed: _loading ? null : _saveProfile,
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: _orange,
                                    foregroundColor: Colors.white,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(30),
                                    ),
                                  ),
                                  child: _loading
                                      ? const SizedBox(
                                    height: 20,
                                    width: 20,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2,
                                      valueColor:
                                      AlwaysStoppedAnimation(
                                          Colors.white),
                                    ),
                                  )
                                      : const Text(
                                    'Save changes',
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ================== PUBLIC "OUR PRODUCT" (VIEW ONLY) ==================

class OurProductPublicScreen extends StatelessWidget {
  const OurProductPublicScreen({super.key});

  static const Color _orange = Color(0xFFF97316);
  static const Color _purple = Color(0xFF9333EA);

  // same prices as MakeOrderScreen
  static const double _priceBuahSegar = 3.50; // RM per kg
  static const double _priceAnakPokok = 0.25; // RM per seedling

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset('assets/image/HOME.png', fit: BoxFit.cover),
          Container(color: Colors.black.withOpacity(0.06)),

          SafeArea(
            child: Column(
              children: [
                // top bar
                Container(
                  height: 56,
                  color: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  child: Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.arrow_back),
                        color: _orange,
                        onPressed: () => Navigator.pop(context),
                      ),
                      const SizedBox(width: 8),
                      const Text(
                        'Our Product',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                          color: Colors.black,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(height: 3, color: _purple),

                Expanded(
                  child: Center(
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.all(16),
                      child: LayoutBuilder(
                        builder: (context, constraints) {
                          final isWide = constraints.maxWidth > 900;

                          final cards = const [
                            _PublicProductCard(
                              title: 'Buah Nenas Segar',
                              imagePath: 'assets/image/buah1.png',
                              priceText: 'RM 3.50 / kg',
                              description:
                              'Nanas segar premium terus dari ladang. '
                                  'Sesuai untuk jualan runcit, jus, dan pemprosesan.',
                            ),
                            _PublicProductCard(
                              title: 'Anak Pokok Nenas',
                              imagePath: 'assets/image/anakpokok.png',
                              priceText: 'RM 0.25 / anak pokok',
                              description:
                              'Anak pokok dijual secara pukal, minimum 10,000. '
                                  'Sesuai untuk penanaman komersial berskala besar.',
                            ),
                          ];

                          // 🔁 responsive: row on desktop, column on mobile
                          if (isWide) {
                            return Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Flexible(child: cards[0]),
                                const SizedBox(width: 24),
                                Flexible(child: cards[1]),
                              ],
                            );
                          } else {
                            return Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                cards[0],
                                const SizedBox(height: 16),
                                cards[1],
                              ],
                            );
                          }
                        },
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _PublicProductCard extends StatelessWidget {
  final String title;
  final String imagePath;
  final String priceText;
  final String description;

  const _PublicProductCard({
    required this.title,
    required this.imagePath,
    required this.priceText,
    required this.description,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(maxWidth: 430),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.97),
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.20),
            blurRadius: 18,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
            child: AspectRatio(
              aspectRatio: 4 / 3,
              child: Image.asset(imagePath, fit: BoxFit.cover),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                    color: Colors.black,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  priceText,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFFF97316), // orange price
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  description,
                  style: const TextStyle(
                    fontSize: 13,
                    color: Colors.black87,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// simple view-only card
class _ProductCardViewOnly extends StatelessWidget {
  final String title;
  final String subtitle;
  final String description;
  final String imagePath;

  const _ProductCardViewOnly({
    required this.title,
    required this.subtitle,
    required this.description,
    required this.imagePath,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(maxWidth: 420),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.96),
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.18),
            blurRadius: 18,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // image
          ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
            child: AspectRatio(
              aspectRatio: 4 / 3,
              child: Image.asset(
                imagePath,
                fit: BoxFit.cover,
              ),
            ),
          ),

          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                    color: Colors.black,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: Colors.orange,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  description,
                  style: const TextStyle(
                    fontSize: 13,
                    color: Colors.black87,
                    height: 1.35,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}


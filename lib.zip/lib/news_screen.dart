import 'package:flutter/material.dart';
import 'auth_service.dart';
import 'news_detail_screen.dart';

class NewsScreen extends StatefulWidget {
  const NewsScreen({super.key});

  @override
  State<NewsScreen> createState() => _NewsScreenState();
}

class _NewsScreenState extends State<NewsScreen> {
  late Future<List<Map<String, dynamic>>> _futureNews;

  @override
  void initState() {
    super.initState();
    _futureNews = AuthService.getNews();
  }

  @override
  Widget build(BuildContext context) {
    const orange = Color(0xFFF97316);
    const purple = Color(0xFF9333EA);

    return Scaffold(
      backgroundColor: Colors.transparent,

      // 🍍 Same app bar style as "Our Product"
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        foregroundColor: orange,
        title: const Text(
          'News',
          style: TextStyle(
            color: Colors.black87,
            fontWeight: FontWeight.w600,
          ),
        ),
        bottom: const PreferredSize(
          preferredSize: Size.fromHeight(2),
          child: SizedBox(
            height: 2,
            child: DecoratedBox(
              decoration: BoxDecoration(color: purple),
            ),
          ),
        ),
      ),

      body: Stack(
        children: [
          // 🍍 Background
          Positioned.fill(
            child: Image.asset(
              "assets/image/bg_product.png",
              fit: BoxFit.cover,
            ),
          ),

          // 📄 News list
          FutureBuilder<List<Map<String, dynamic>>>(
            future: _futureNews,
            builder: (context, snap) {
              if (snap.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }

              if (!snap.hasData || snap.data!.isEmpty) {
                return const Center(
                  child: Text(
                    'No News Found',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                    ),
                  ),
                );
              }

              final news = snap.data!;
              final screenWidth = MediaQuery.of(context).size.width;

              // card width: stick to the right, leave left side free
              const maxCardWidth = 900.0;
              final cardWidth = screenWidth < maxCardWidth
                  ? screenWidth * 0.7    // ~70% of screen on small screens
                  : maxCardWidth;        // cap on big screens

              return ListView.builder(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 16,
                ),
                itemCount: news.length,
                itemBuilder: (context, i) {
                  final item = news[i];
                  final imageUrl = item['image_url'] ?? '';

                  return GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => NewsDetailScreen(news: item),
                        ),
                      );
                    },
                    child: Align(
                      alignment: Alignment.centerRight, // 👉 push to the right
                      child: SizedBox(
                        width: cardWidth,
                        child: Container(
                          margin: const EdgeInsets.only(bottom: 20),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(24),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.20),
                                blurRadius: 12,
                                offset: const Offset(0, 6),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // 🖼 Image
                              if (imageUrl.isNotEmpty)
                                ClipRRect(
                                  borderRadius: const BorderRadius.vertical(
                                    top: Radius.circular(24),
                                  ),
                                  child: Image.network(
                                    imageUrl,
                                    height: 180,
                                    width: double.infinity,
                                    fit: BoxFit.cover,
                                  ),
                                ),

                              // 📝 Text section
                              Padding(
                                padding: const EdgeInsets.all(16),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      item['title']
                                          .toString()
                                          .toUpperCase(),
                                      style: const TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w700,
                                        color: Colors.black87,
                                      ),
                                    ),
                                    const SizedBox(height: 6),
                                    Text(
                                      item['content'].toString(),
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(
                                        color: Colors.black87,
                                        fontSize: 14,
                                        height: 1.5,
                                      ),
                                    ),
                                    const SizedBox(height: 8),
                                    const Text(
                                      "Tap to view more",
                                      style: TextStyle(
                                        color: Colors.orange,
                                        fontSize: 11,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                },
              );
            },
          ),
        ],
      ),
    );
  }
}

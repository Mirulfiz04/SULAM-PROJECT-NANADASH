import 'package:flutter/material.dart';
import 'auth_service.dart';
import 'session_manager.dart';

class OrdersScreen extends StatefulWidget {
  const OrdersScreen({super.key});

  @override
  State<OrdersScreen> createState() => _OrdersScreenState();
}

class _OrdersScreenState extends State<OrdersScreen> {
  late Future<List<dynamic>> _futureMyOrders;

  @override
  void initState() {
    super.initState();
    _futureMyOrders = _loadOrders();
  }

  // --- Load orders for the logged-in customer ------------------------------
  Future<List<dynamic>> _loadOrders() async {
    final session = SessionManager();
    final idString = await session.getUserId(); // String?

    if (idString == null) return [];

    final customerId = int.tryParse(idString);
    if (customerId == null) return [];

    return await AuthService.getMyOrders(customerId);
  }

  Future<void> _reload() async {
    setState(() {
      _futureMyOrders = _loadOrders();
    });
  }

  Color _statusColor(String status) {
    switch (status.toLowerCase()) {
      case 'accepted':
        return Colors.green;
      case 'rejected':
        return Colors.redAccent;
      default:
        return Colors.orange;
    }
  }

  String _fmtDate(String? s) {
    if (s == null || s.isEmpty || s == 'null') return '-';
    return s; // you can format nicer with DateFormat later
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.orange,
        title: const Text("My Orders"),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _reload,
          )
        ],
      ),
      body: FutureBuilder<List<dynamic>>(
        future: _futureMyOrders,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          final orders = snapshot.data ?? [];

          if (orders.isEmpty) {
            return const Center(
              child: Text(
                "You have no orders yet.",
                style: TextStyle(fontSize: 16),
              ),
            );
          }

          return ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: orders.length,
            itemBuilder: (context, index) {
              final o = orders[index];

              final orderId   = o['order_id']?.toString() ?? '-';
              final total     = (o['total_amount'] ?? o['total'] ?? 0).toString();
              final status    = o['status']?.toString() ?? 'pending';

              final product   = o['product_name']?.toString() ?? 'Unknown product';
              final quantity  = o['quantity']?.toString() ?? '-';
              // IMPORTANT: this must match the key from PHP
              final address   = o['delivery_address']?.toString()
                  ?? o['delivery_address']?.toString()
                  ?? '-';
              final requested = _fmtDate(o['requested_at']?.toString());
              final accepted  = _fmtDate(o['accepted_at']?.toString());

              final statusColor = _statusColor(status);

              return Card(
                margin: const EdgeInsets.only(bottom: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                elevation: 3,
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Header row: Order ID + status chip
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Order #$orderId',
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: statusColor.withOpacity(0.12),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Text(
                              status[0].toUpperCase() + status.substring(1),
                              style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                                color: statusColor,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),

                      Text(
                        product,
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text('Quantity: $quantity'),

                      const SizedBox(height: 8),
                      Row(
                        children: [
                          const Icon(Icons.schedule, size: 14),
                          const SizedBox(width: 4),
                          Text('Requested: $requested'),
                        ],
                      ),
                      const SizedBox(height: 2),
                      Row(
                        children: [
                          const Icon(Icons.check_circle_outline, size: 14),
                          const SizedBox(width: 4),
                          Text('Accepted: $accepted'),
                        ],
                      ),
                      const SizedBox(height: 2),
                      Row(
                        children: [
                          const Icon(Icons.location_on_outlined, size: 14),
                          const SizedBox(width: 4),
                          Expanded(child: Text(address)),
                        ],
                      ),

                      const SizedBox(height: 10),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          const Text(
                            'Total ',
                            style: TextStyle(fontWeight: FontWeight.w600),
                          ),
                          Text('RM $total'),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

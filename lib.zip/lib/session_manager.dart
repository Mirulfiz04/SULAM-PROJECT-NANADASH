import 'package:shared_preferences/shared_preferences.dart';

class SessionManager {
  static const String keyUserId = 'user_id';
  static const String keyUserName = 'user_name';
  static const _keyUserEmail = 'user_email';
  static const String keyUserRole = 'user_role';

  // ===== SAVE SESSION AFTER LOGIN =====
  Future<void> saveUserSession({
    required int id,
    required String name,
    required String role,
    String? email,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(keyUserId, id);
    await prefs.setString(keyUserName, name);
    await prefs.setString(keyUserRole, role);

    // ✅ Always save email (even if empty string)
    await prefs.setString(_keyUserEmail, email ?? '');
  }

  Future<String?> getUserRole() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(keyUserRole); // 'admin', 'customer', or null
  }

  Future<String?> getUserName() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(keyUserName);
  }

  Future<String?> getUserEmail() async {
    final prefs = await SharedPreferences.getInstance();
    final v = prefs.getString(_keyUserEmail);
    return (v == null || v.isEmpty) ? null : v;
  }

  Future<String?> getUserId() async {
    final prefs = await SharedPreferences.getInstance();
    final id = prefs.getInt(keyUserId);
    // convert to String because most of the time we use it as String
    return id?.toString();
  }

  Future<void> clearSession() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
  }
}



